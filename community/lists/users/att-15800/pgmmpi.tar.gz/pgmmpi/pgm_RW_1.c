#include<stdio.h>
#include<stdlib.h>

#define SIZE_X 640
#define SIZE_Y 480


/******************** Main Porgram *************************/

void main(int argc, char *argv[])
{                       	// Variable Declration 
  FILE *cpp1,*cpp2;
  char dummy[50]="";
  int m=SIZE_X,n=SIZE_Y;
  int  image_input[SIZE_X][SIZE_Y],image_output[SIZE_X][SIZE_Y];
  int i,j,temp1;

   

  /********* Open image file for read & write ************/

  //cpp1=fopen("2.pgm", "r+");
cpp1=fopen(argv[1], "r+");
  //cpp2=fopen("2_Negative.pgm", "w");
cpp2=fopen(argv[2], "w");

  /**************** Read the header part of the image *************/

  fgets(dummy,50,cpp1);
  do{  fgets(dummy,50,cpp1); } while(dummy[0]=='#');
  fgets(dummy,50,cpp1);

  /**************Print information in the write image file *****/
 
  fprintf(cpp2,"P2\n%d %d\n255\n",m,n);
 
  
  /************* Read pixel values ****************/
  
  //image_in = allocate_image(m,n);
  
  for (j = 0; j <n; j++)
   for (i = 0; i <m; i++)
    {
  	  fscanf(cpp1,"%d",&temp1);
	  image_input[i][j] = temp1;
    }

/************* Write pixel values into a file****************/
  
  for(j=0;j<n;j++)
	for(i=0;i<m;i++) 
	   fprintf(cpp2,"%d ", 255-image_input[i][j]);
  
 } 
