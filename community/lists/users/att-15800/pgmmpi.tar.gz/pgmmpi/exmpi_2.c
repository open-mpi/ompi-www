#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mpi.h"

#define SIZE_X 640
#define SIZE_Y 480



  
 int main(int argc, char **argv) 
{
    FILE *FR,*FW;
    int ierr;
    int rank, size;
    int ncells;
    int greys[SIZE_X][SIZE_Y];
    int rows,cols, maxval;
    
    int mystart, myend, myncells;
    const int IONODE=0;
    int *disps, *counts, *mydata;
    int *data;
    int i,j,temp1;
    char dummy[50]="";
	
	



    ierr = MPI_Init(&argc, &argv);
    if (argc != 3) {
        fprintf(stderr,"Usage: %s infile outfile\n",argv[0]);
        fprintf(stderr,"outputs the negative of the input file.\n");
        return -1;
    }            

    ierr  = MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    ierr = MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (ierr) {
        fprintf(stderr,"Catastrophic MPI problem; exiting\n");
        MPI_Abort(MPI_COMM_WORLD,1);
    }

    if (rank == IONODE) {
        //if (read_pgm(argv[1], &greys, &rows, &cols, &maxval)) {
         //   fprintf(stderr,"Could not read file; exiting\n");
         //   MPI_Abort(MPI_COMM_WORLD,2);
         
         rows=SIZE_X;
         cols=SIZE_Y;
         maxval=255;
         FR=fopen(argv[4], "r+");
        
         fgets(dummy,50,FR);
         do{  fgets(dummy,50,FR); } while(dummy[0]=='#');
         fgets(dummy,50,FR);

         for (j = 0; j <cols; j++)
         {
           for (i = 0; i <rows; i++)
           {
  	         fscanf(FR,"%d",&temp1);
	         greys[i][j] = temp1;
           }
         }
    }

        ncells = rows*cols;
        disps = (int *)malloc(size * sizeof(int));
        counts= (int *)malloc(size * sizeof(int));
        data = &(greys[0][0]); /* we know all the data is contiguous */
        
    /* everyone calculate their number of cells */
    ierr = MPI_Bcast(&ncells, 1, MPI_INT, IONODE, MPI_COMM_WORLD);
    myncells = ncells/size;
    mystart = rank*myncells;
    myend   = mystart + myncells - 1;
    if (rank == size-1) myend = ncells-1;
    myncells = (myend-mystart)+1;
    mydata = (int *)malloc(myncells * sizeof(int));

    /* assemble the list of counts.  Might not be equal if don't divide evenly. */
    ierr = MPI_Gather(&myncells, 1, MPI_INT, counts, 1, MPI_INT, IONODE, MPI_COMM_WORLD);
    if (rank == IONODE) {
        disps[0] = 0;
        for (i=1; i<size; i++) {
            disps[i] = disps[i-1] + counts[i-1];
        }
    }

    /* scatter the data */
    ierr = MPI_Scatterv(data, counts, disps, MPI_INT, mydata, myncells, MPI_INT, IONODE, MPI_COMM_WORLD);

    /* everyone has to know maxval */
    ierr = MPI_Bcast(&maxval, 1, MPI_INT, IONODE, MPI_COMM_WORLD);

    for (i=0; i<myncells; i++)
        mydata[i] = maxval-mydata[i];

    /* Gather the data */
    ierr = MPI_Gatherv(mydata, myncells, MPI_INT, data, counts, disps, MPI_INT, IONODE, MPI_COMM_WORLD);

    if (rank == IONODE) 
    {
//	  write_pgm(argv[2], greys, rows, cols, maxval);
      FW=fopen(argv[5], "w");
      fprintf(FW,"P2\n%d %d\n255\n",rows,cols);    
      for(j=0;j<cols;j++)
		for(i=0;i<rows;i++) 
	   fprintf(FW,"%d ", greys[i][j]);
    }

    free(mydata);
    if (rank == IONODE) {
        free(counts);
        free(disps);
        //free(&(greys[0][0]));
        //free(greys);
                
    }
    fclose(FR);
    fclose(FW);
    MPI_Finalize();
    return 0;
}

