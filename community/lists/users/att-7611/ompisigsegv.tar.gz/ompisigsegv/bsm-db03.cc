

MPI_Datatype data_03_00001;
MPI_Win win_03_00002;
void* mem_03_00003;
MPI_Win win_03_00004;
void* mem_03_00005;
void* mem_03_00006;
void* mem_03_00007;
MPI_Comm comm_03_00008;
MPI_Comm comm_03_00009;
MPI_Comm comm_03_00010;

void func_03_00001()
{
	MPI_Type_contiguous(3, MPI_DOUBLE, &data_03_00001);
	MPI_Type_commit(&data_03_00001);
}

void func_03_00002()
{
	MPI_Alloc_mem(1074456, MPI_INFO_NULL, &mem_03_00003);
	MPI_Win_create(mem_03_00003, 1074456, 24, MPI_INFO_NULL, MPI_COMM_WORLD, &win_03_00002);
}

void func_03_00003()
{
	MPI_Alloc_mem(1074456, MPI_INFO_NULL, &mem_03_00005);
	MPI_Win_create(mem_03_00005, 1074456, 24, MPI_INFO_NULL, MPI_COMM_WORLD, &win_03_00004);
}

void sub_03(void)
{
	MPI_Comm_dup(MPI_COMM_WORLD, &comm_03_00010);
	MPI_Comm_split(MPI_COMM_WORLD, 1, 3, &comm_03_00009);
	MPI_Comm_split(comm_03_00010, -32766, 3, &comm_03_00008);
	MPI_Alloc_mem(1074456, MPI_INFO_NULL, &mem_03_00007);
	MPI_Alloc_mem(1074456, MPI_INFO_NULL, &mem_03_00006);
	func_03_00003();
	func_03_00002();
	func_03_00001();
	MPI_Win_fence(0, win_03_00004);
	MPI_Win_fence(0, win_03_00004);
}

