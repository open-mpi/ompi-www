
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#include "bsm-db00.cc"
#include "bsm-db01.cc"
#include "bsm-db02.cc"
#include "bsm-db03.cc"

int main(int argc, char** argv, char** envp)
{
	int myrank, numprocs;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

	if (numprocs != 4) {
		printf(" started with wrong number of procs (need 4 procs)");
	}

	if (0 == myrank) {
		sub_00();
	}
	if (1 == myrank) {
		sub_01();
	}
	if (2 == myrank) {
		sub_02();
	}
	if (3 == myrank) {
		sub_03();
	}
	return MPI_Finalize();
}
