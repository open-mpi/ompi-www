#!/usr/bin/env bash

# ompi
valgrind ./a.out &> vg${OMPI_COMM_WORLD_RANK}
# mpich2
# ./a.out &> vg${PMI_RANK}
