

MPI_Datatype data_02_00001;
MPI_Win win_02_00002;
void* mem_02_00003;
MPI_Win win_02_00004;
void* mem_02_00005;
void* mem_02_00006;
void* mem_02_00007;
MPI_Comm comm_02_00008;
MPI_Comm comm_02_00009;
MPI_Comm comm_02_00010;

void func_02_00001()
{
	MPI_Type_contiguous(3, MPI_DOUBLE, &data_02_00001);
	MPI_Type_commit(&data_02_00001);
}

void func_02_00002()
{
	MPI_Alloc_mem(1074456, MPI_INFO_NULL, &mem_02_00003);
	MPI_Win_create(mem_02_00003, 1074456, 24, MPI_INFO_NULL, MPI_COMM_WORLD, &win_02_00002);
}

void func_02_00003()
{
	MPI_Alloc_mem(1074456, MPI_INFO_NULL, &mem_02_00005);
	MPI_Win_create(mem_02_00005, 1074456, 24, MPI_INFO_NULL, MPI_COMM_WORLD, &win_02_00004);
}

void sub_02(void)
{
	MPI_Comm_dup(MPI_COMM_WORLD, &comm_02_00010);
	MPI_Comm_split(MPI_COMM_WORLD, 1, 2, &comm_02_00009);
	MPI_Comm_split(comm_02_00010, -32766, 2, &comm_02_00008);
	MPI_Alloc_mem(1074456, MPI_INFO_NULL, &mem_02_00007);
	MPI_Alloc_mem(1074456, MPI_INFO_NULL, &mem_02_00006);
	func_02_00003();
	func_02_00002();
	func_02_00001();
	MPI_Win_fence(0, win_02_00004);
	MPI_Win_fence(0, win_02_00004);
}

