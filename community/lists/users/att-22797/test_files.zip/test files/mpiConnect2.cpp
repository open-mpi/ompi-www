/**
 * Author:
 *   Andrew Burns
 *   andrew.j.burns2@us.army.mil
 *   US Army Research Laboratory
 *   Aberdeen Proving Ground, MD
 *
 * Date of Creation: 10/15/2013
 */

#include <mpi.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <sstream>
#include <fstream>

int main(int argc, char *argv[])
{
        int size, id;
        int val = 0;
        MPI_Status status;
        MPI_Comm comm = MPI_COMM_WORLD;
        MPI_Comm tempComm;
        MPI_Comm mergeComm = comm;
        int callstatus;

        MPI_Init(&argc, &argv);

        MPI_Comm_rank(comm, &id);
        MPI_Comm_size(comm, &size);

        system("hostname");

        char portName[MPI_MAX_PORT_NAME];

        std::ifstream connectFile("connect.cfg");
        std::string connectLine;
        if (connectFile.is_open())
        {
                getline(connectFile, connectLine);
        }
        strcpy(portName, connectLine.c_str());

        printf("connecting to port %s on core %d\n", portName, id);

        callstatus = MPI_Comm_connect(portName, MPI_INFO_NULL, 0, mergeComm, &tempComm);

        if (callstatus != MPI_SUCCESS)
        {
                printf("accept failed\n");
        }
        else
        {
                printf("accept suceeded\n");
        }

        callstatus = MPI_Intercomm_merge(tempComm, true, &mergeComm);

        if (callstatus != MPI_SUCCESS)
        {
                printf("merge failed\n");
        }
        else
        {
                printf("merge succeded\n");
        }

        // Failure occurs about here

        MPI_Bcast(&val, 1, MPI_INT, 0, mergeComm);

        printf("Connect2 %d: new value = %d\n", id, val);

        MPI_Finalize();

        return 0;
}