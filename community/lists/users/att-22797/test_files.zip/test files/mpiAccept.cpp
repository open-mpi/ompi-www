/**
 * Author:
 *   Andrew Burns
 *   andrew.j.burns2@us.army.mil
 *   US Army Research Laboratory
 *   Aberdeen Proving Ground, MD
 *
 * Date of Creation: 10/15/2013
 */

#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <fstream>

int main(int argc, char *argv[])
{
        int size, id;
        int val = 0;
        MPI_Status status;
        MPI_Comm comm = MPI_COMM_WORLD;
        MPI_Comm tempComm;
        MPI_Comm mergeComm = comm;
        int callstatus;

        MPI_Init(&argc, &argv);

        MPI_Comm_rank(comm, &id);
        MPI_Comm_size(comm, &size);

        system("hostname");

        char portName[MPI_MAX_PORT_NAME];

        if (id == 0)
        {
                MPI_Open_port(MPI_INFO_NULL, portName);

                std::ofstream connectFile ("connect.cfg");
                if (connectFile.is_open())
                {
                        connectFile << portName;
                        connectFile.close();
                }
        }

        MPI_Bcast(&portName, MPI_MAX_PORT_NAME, MPI_CHAR, 0, comm);

        printf("port %s opened on core %d\n", portName, id);

        MPI_Comm_accept(portName, MPI_INFO_NULL, 0, mergeComm, &tempComm);
        MPI_Intercomm_merge(tempComm, false, &mergeComm);

        if (id == 0)
        {
                val = 1;
        }

        MPI_Bcast(&val, 1, MPI_INT, 0, mergeComm);

        printf("Accept %d: new value = %d\n", id, val);

        printf("accepting process # 2\n");

        callstatus = MPI_Comm_accept(portName, MPI_INFO_NULL, 0, mergeComm, &tempComm);

        if (callstatus != MPI_SUCCESS)
        {
                printf("accept failed\n");
        }
        else
        {
                printf("accept suceeded\n");
        }

        callstatus = MPI_Intercomm_merge(tempComm, false, &mergeComm);

        if (callstatus != MPI_SUCCESS)
        {
                printf("merge failed\n");
        }
        else
        {
                printf("merge succeded\n");
        }

        if (id == 0)
        {
                val = 10;
        }

        // Failure occurs about here

        MPI_Bcast(&val, 1, MPI_INT, 0, mergeComm);

        printf("Accept %d val = %d\n", id, val);

        if (id == 0)
        {
                MPI_Close_port(portName);
        }

        MPI_Finalize();

        return 0;
}