#include <mpi.h>
#include <stdio.h>

int MPI_Comm_size (MPI_Comm c, int *s)
{
	int i;
	printf ("entering MPI_Comm_size\n");
	i = PMPI_Comm_size (c, s);
	printf ("leaving MPI_Comm_size\n");
	return i;
}

int MPI_Comm_rank (MPI_Comm c, int *r)
{
	int i;
	printf ("entering MPI_Comm_rank\n");
	i = PMPI_Comm_rank (c, r);
	printf ("leaving MPI_Comm_rank\n");
	return i;
}

int MPI_Ibarrier (MPI_Comm c, MPI_Request *r)
{
	int i;
	printf ("entering MPI_Ibarrier\n");
	i = PMPI_Ibarrier (c, r);
	printf ("leaving MPI_Ibarrier\n");
	return i;
}
