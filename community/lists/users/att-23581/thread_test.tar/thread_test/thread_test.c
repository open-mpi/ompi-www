/****************************************************************************** 

  (c) 2011-2013 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  This work is open source software, licensed under the terms of the
  BSD license as described in the LICENSE file in the top-level directory.

*******************************************************************************/
#include <mpi.h>
#include <pthread.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

int nthreads = 4;

#define N (100*1000)

static void test_mpi(int self)
{
  double* message = malloc(N*sizeof(double));
  for (int i=0; i < N; ++i)
    message[i] = i*1.0;
  MPI_Request request;
  MPI_Issend(
      message,
      N,
      MPI_DOUBLE,
      0,
      (self+1)%nthreads,
      MPI_COMM_WORLD,
      &request);
  double* message2 = malloc(N*sizeof(double));
  MPI_Recv(
      message2,
      N,
      MPI_DOUBLE,
      0,
      (self+nthreads-1)%nthreads,
      MPI_COMM_WORLD,
      MPI_STATUS_IGNORE);
  MPI_Wait(&request,MPI_STATUS_IGNORE);
  free(message);
  free(message2);
}

static void* thread_main(void* p)
{
  test_mpi((int)(ptrdiff_t)p);
  return NULL;
}

static void test_threads(void)
{
  pthread_t* threads = malloc(nthreads*sizeof(pthread_t));
  for (int i=1; i < nthreads; ++i)
    pthread_create(threads+i,NULL,thread_main,(void*)(ptrdiff_t)i);
  thread_main(0);
  for (int i=1; i < nthreads; ++i)
    pthread_join(threads[i],NULL);
  free(threads);
}

int main()
{
  int provided;
  MPI_Init_thread(NULL,NULL,MPI_THREAD_MULTIPLE,&provided);
  assert(MPI_THREAD_MULTIPLE == provided);
  test_threads();
  MPI_Finalize();
  return 0;
}
