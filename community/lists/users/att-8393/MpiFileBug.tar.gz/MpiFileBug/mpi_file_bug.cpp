/* File:   mpi_file_bug.cpp
 * Author: Manuel Holtgrewe <holtgrewe@ira.uka.de>
 */

#include <cstdio>

#include <mpi.h>
#include <stdint.h>

const int32_t kHeader[] = {'D', 'A', 'A'};

void WriteInteger4(const char *filename)
{
  MPI::File f = MPI::File::Open(MPI::COMM_WORLD, filename,
                                MPI::MODE_WRONLY | MPI::MODE_CREATE,
                                MPI::INFO_NULL);

  printf("f.Get_type_extent(MPI::INTEGER) == %d\n",
         f.Get_type_extent(MPI::INTEGER));
  printf("f.Get_type_extent(MPI::INTEGER4) == %d\n",
         f.Get_type_extent(MPI::INTEGER4));

  f.Set_size(8 * sizeof(int32_t));
  f.Seek(0, MPI_SEEK_SET);
  f.Write(kHeader, 3, MPI::INTEGER4);
  int32_t v = 1;
  f.Write(&v, 1, MPI::INTEGER4);
  f.Close();

}

void WriteInteger(const char *filename)
{
  MPI::File f = MPI::File::Open(MPI::COMM_WORLD, filename,
                                MPI::MODE_WRONLY | MPI::MODE_CREATE,
                                MPI::INFO_NULL);
  f.Set_size(8 * sizeof(int32_t));
  f.Seek(0, MPI_SEEK_SET);
  f.Write(kHeader, 3, MPI::INTEGER);
  int32_t v = 1;
  f.Write(&v, 1, MPI::INTEGER);
  f.Close();

}

int main(int argc, char **argv)
{
  const char *filename = "test.integer4.dat";
  MPI::Init();

  MPI_Aint extent;
  MPI_Type_extent(MPI_INTEGER, &extent);
  printf("MPI_Type_extent(MPI_INTEGER) == %d\n", extent);
  MPI_Type_extent(MPI_INTEGER4, &extent);
  printf("MPI_Type_extent(MPI_INTEGER4) == %d\n", extent);

  WriteInteger4("test.integer4.dat");
  WriteInteger("test.integer.dat");

  MPI::Finalize();
  return 0;
}

