#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>


int main(int argc, char ** argv) {
	char portname[MPI_MAX_PORT_NAME + 1];
	MPI_Comm comm;


	MPI_Init(&argc,&argv);
	
	printf("+ looking up the publisher\n");
	if (MPI_Lookup_name("goodName", MPI_INFO_NULL, portname)!=MPI_SUCCESS)
		printf("+lookup name failed\n");

	printf("++ connecting with publisher\n");
	if (MPI_Comm_connect(portname, MPI_INFO_NULL, 0, MPI_COMM_WORLD, &comm) != MPI_SUCCESS)
		printf("++ connect failed\n");

	printf("+++ accepted connection from %d\n",(int) comm);
	sleep(20);
	MPI_Comm_disconnect(&comm);

	MPI_Finalize();
}
