#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char ** argv) {
	char portname[MPI_MAX_PORT_NAME + 1];
	MPI_Comm comm;

	
	MPI_Init(&argc,&argv);

	printf("* opening port\n");
	if (MPI_Open_port(MPI_INFO_NULL, portname)!=MPI_SUCCESS)
	 	printf("* could not open port\n");

	printf("** publishing the name\n");
	if (MPI_Publish_name("goodName", MPI_INFO_NULL, portname)!=MPI_SUCCESS)
		printf("** could not publish the name\n");

	printf("*** accepting connection \n");
	MPI_Comm_accept(portname, MPI_INFO_NULL, 0, MPI_COMM_WORLD, &comm);
	printf("*** accepted connection from %d\n",(int) comm);
	sleep(20);
	MPI_Comm_disconnect(&comm);

	MPI_Finalize();
}
