#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <mpi.h>

int __NUMNODES, __MYPROCID;

#define MSG_TAG(i) i

int main( int argc, char *argv[] ){
  double         elapsed_time;
  int            i,j, to;
  int            recv_from;
  MPI_Status status;
  MPI_Request request;
  char         *sbuffer,*rbuffer;
  register double   t0, t1;

 //number of iterations 
  int iters;
  //total bytes
  double total_bytes;
  
  //message len
  int len = 8;
  
printf("Starting...\n");   
  //bytes to be sent
  total_bytes = (1024 * 512);

  //number of iterations to send total_bytes bytes with messages of size 'len'
  iters = total_bytes / len;
  
  sbuffer = (char *)malloc(len);
  rbuffer = (char *)malloc(len);
  memset( sbuffer, 0, len);
  memset( rbuffer, 0, len );
    
  
  MPI_Init( &argc, &argv );
  MPI_Comm_size( MPI_COMM_WORLD, &__NUMNODES );
  MPI_Comm_rank( MPI_COMM_WORLD, &__MYPROCID );

  
  if(__MYPROCID == 0){
    to = 1;
    recv_from = MPI_ANY_SOURCE;
    
    MPI_Recv(rbuffer,len,MPI_BYTE,recv_from,0,MPI_COMM_WORLD,&status);
    
    t0=MPI_Wtime();
    for (j = 0 ; j < iters; j++){
    	MPI_Send( sbuffer, len, MPI_BYTE,to,MSG_TAG(j),MPI_COMM_WORLD);
    }//iters
    //wait untill all messages was receved at rank 1	    
    MPI_Recv(rbuffer,len,MPI_BYTE,recv_from,0,MPI_COMM_WORLD,&status);

    t1=MPI_Wtime();
    
    elapsed_time = t1-t0;
    printf("Elapsed: %f \n", elapsed_time);
    
  }
  
  if(__MYPROCID == 1){
    to = 0;
    recv_from = MPI_ANY_SOURCE;

    MPI_Send(sbuffer,len,MPI_BYTE,to,0,MPI_COMM_WORLD);

     for (j = 0 ; j < iters; j++){
        MPI_Recv(rbuffer,len,MPI_BYTE,recv_from ,MSG_TAG(j),MPI_COMM_WORLD, &status);
       //MPI_Irecv(rbuffer,len,MPI_BYTE,recv_from ,MSG_TAG(j),MPI_COMM_WORLD,&request);
       //MPI_Wait(&request,&status);
     }
     //tell rank 0 when all messages was received
     MPI_Send(sbuffer,len,MPI_BYTE,to,0,MPI_COMM_WORLD);
  }

  MPI_Finalize();
  free(sbuffer);
  free(rbuffer);
  return(0);

}

