#include <stdio.h>
#include <string.h>
#include "mpi.h"

main(int argc, char* argv[])
{
   int my_rank;		// rank of process
   int p;		// number of process
   int source;		// rank of sender
   int dest;		// rank of receiver
   int tag = 0;		// tag for messages
   char message[100];	// storage for message
   MPI_Status status;	// return status for receive

   printf ("calling init\n");

   // Startup MPI
   MPI_Init(&argc, &argv);

   printf ("return from init\n");

   // Find out process rank
   MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

   // Find out number of processes
   MPI_Comm_size(MPI_COMM_WORLD, &p);
   //Test
   printf("Before waiting for messages. I am rank=%d, processes=%d\n", my_rank,p);

   if (my_rank != 0) 
   {
      //Test
      printf("I am process %d!\n", my_rank);
      // Create Message
      sprintf(message, "Greetings from process %d!", my_rank);
      dest = 0;
      // Use strlen+1 so that '\0' gets transmitted
      MPI_Send(message, strlen(message)+1, MPI_CHAR, dest, tag, MPI_COMM_WORLD);
   }
   else  // my_rank ==0
   {
      for (source = 1; source < p; source++)
      {
        printf("Waiting message from source %d of %d\n", source, p);
        MPI_Recv(message, 100, MPI_CHAR, source, tag, MPI_COMM_WORLD, &status);
        printf("%s\n", message);
      }
   }

   // Shut down MPI
   MPI_Finalize();
}
