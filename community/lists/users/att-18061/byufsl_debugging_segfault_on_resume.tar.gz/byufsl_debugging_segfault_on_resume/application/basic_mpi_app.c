#include <stdio.h>
#include <mpi.h>

#ifndef BUFSIZ
#define BUFSIZ 1024
#endif

#ifndef MAXCOUNT
#define MAXCOUNT 50
#endif

#ifndef SLEEPDELAY
#define SLEEPDELAY 30
#endif

int main(int argc, char *argv[]) {
	char name[BUFSIZ];
	int length;
	int my_rank;
	int num_ranks;
	int count;

	MPI_Init(&argc, &argv);
	MPI_Get_processor_name(name, &length);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
	MPI_Comm_size(MPI_COMM_WORLD, &num_ranks);


	printf("Rank %u of %u: running on host %s\n", my_rank, num_ranks, name);

	for(count = 0; count < MAXCOUNT; count++) {
		printf("Rank %u of %u: Iteration %u\n", my_rank, num_ranks, count);

		if(my_rank==0) {
			sleep(SLEEPDELAY);
		}

		MPI_Barrier(MPI_COMM_WORLD);
	}

	MPI_Finalize();
}
