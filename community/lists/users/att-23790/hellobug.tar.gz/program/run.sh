#!/bin/bash
mpirun -np 8 java Hello
