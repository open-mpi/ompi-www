#include "mpi.h"
#include <stdio.h>

int main(int argc, char *argv[]) {
  int rc, me;
    char pname[MPI_MAX_PROCESSOR_NAME];
    int plen;
    int i, j;

    MPI_Init(
       &argc,
       &argv
    );

    rc = MPI_Comm_rank(
            MPI_COMM_WORLD,
            &me
    );

    if (rc != MPI_SUCCESS)
    {
       return rc;
    }

    MPI_Get_processor_name(
       pname,
       &plen
    );

    printf("%s:Hello world from %d\n", pname, me);
    
    MPI_Finalize();

    return 0; 
}
