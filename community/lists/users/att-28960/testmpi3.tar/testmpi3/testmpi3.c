//=======================================================================
//
//  This program does halo exchange

#include "mpi.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

  /*        MAIN    */
  int
  main (int argc, char *argv[])
  {
    MPI_Comm comm = MPI_COMM_WORLD;
    /* to be used for exchanges */
    int rank, numtasks;

    /* related to MPI-3 shm*/
    MPI_Comm shmcomm; /* shm communicator  */ 
    MPI_Win win;      /* shm window object */ 
    int shm_size;     /* shmcomm size */
    int *shar_mem;         /* shm memory to be allocated on each node */

    /* current rank exchanges value with partners */
    int const n_partners = 2; /* size of partners array in 1D-ring topology*/
    int partners[n_partners];
    int *maps_shm;   /* mapping in shm communicator */
    int **shar_pntr; /* ptrs to shared mem window for each partner*/
    int j, icolor,partner, alloc_len;
    int on_node_partners=0, off_node_partners=0;
    int nprocsh,ranksh;
   int  dsp_unit;
   MPI_Aint sz;

     /* non-blocking inter-node */
    MPI_Request *reqs, *rq;
    int halo[n_partners];       /* int recv buffers */
    int req_num = 2;      /* each inter-node exchange needs a pair of MPI_Irecv and MPI_Isend */
    req_num *= 1;         /* multiply by number of exchanges */


    MPI_Init (&argc, &argv); 
    MPI_Comm_size (comm, &numtasks);
    MPI_Comm_rank (comm, &rank);
    

    /* The 1D ring is defined in partners array. It can be easily expanded to the higher order stencils.
       The current rank has 2 neighbours: previous and next, i.e., prev-rank-next */
    partners[0] = rank-1; /* prev */
    partners[1] = rank+1; /* next */
    /* We will use periodic boundary conditions here */
    if (rank == 0)  partners[0] = numtasks - 1;
    if (rank == (numtasks - 1))  partners[1] = 0;

    /* MPI-3 SHM collective creates shm communicator.  On NUMA systems it will always return 
       the shm communicator that is the same as MPI_COMM_WORLD */

     /* MPI_Comm_split_type (comm, MPI_COMM_TYPE_SHARED, 0, MPI_INFO_NULL, &shmcomm); */

    /* Replace the above with explicit splitting of 'comm' to mimic a multi-node system. 
       icolor=0 creates single shared memory space, same as above  */

    /* This icolor creates 2 equal sized shared memory spaces */
       icolor = (rank*2+1)/numtasks; 
       MPI_Comm_split (comm, icolor, 0 , &shmcomm); 

    MPI_Barrier (comm);  
           
    maps_shm = (int*)malloc(n_partners*sizeof(int)); /* allocate maps_shm */

  /* defines global rank  -> shmcomm rank mapping;
 *      output: maps_shm is array of ranks in shmcomm  */

    MPI_Comm_size (shmcomm, &nprocsh);
    MPI_Comm_rank (shmcomm, &ranksh);
  {
    MPI_Group world_group, shared_group;

    /* create MPI groups for global communicator and shm communicator */
    MPI_Comm_group (MPI_COMM_WORLD, &world_group);
    MPI_Comm_group (shmcomm, &shared_group);

    MPI_Group_translate_ranks (world_group, n_partners, partners, shared_group, maps_shm);
  }

  /* count number of intra and inter node partners */
  {
   for (j=0; j<n_partners; j++)
     /* If partner has a valid mapping in shm communicator then it is on the same node */
     maps_shm[j] == MPI_UNDEFINED ? (off_node_partners)++ : (on_node_partners)++;
  }

    alloc_len = sizeof(int); 
    if (on_node_partners > 0)
 {
     /* allocate shared memory windows on each node for intra-node partners  */
     MPI_Win_allocate_shared (alloc_len, 1, MPI_INFO_NULL, shmcomm, /* inputs to MPI-3 SHM collective */
                              &shar_mem, &win);  /* outputs: shar_mem - initial address of window; win - window object */

     /* pointers to shar_mem windows */
     shar_pntr = (int **)malloc(n_partners*sizeof(int*));  

  /* returns pointers to shar_mem windows shar_pntr */
  {
    for (j=0; j<n_partners; j++)
    {
      shar_pntr[j] = NULL;
      if (maps_shm[j] != MPI_UNDEFINED)
       /* MPI_Win_shared_query queries the process-local address for memory segments created with MPI_Win_allocate_shared.
 *          This function can return different process-local addresses for the same physical memory on different processes.  */
          MPI_Win_shared_query (win, maps_shm[j], &sz, &dsp_unit, &shar_pntr[j]); /* returns shar_pntr */
    }
  }

 }
    /* allocate MPI Request resources for inter-node comm. */
    if(off_node_partners > 0)
    {
        reqs = (MPI_Request*)malloc(req_num*off_node_partners*sizeof(MPI_Request));
        rq = reqs;
    }

    /* start halo exchange */

    /* Entering MPI-3 RMA access epoch required for MPI-3 shm */


     MPI_Win_fence(0, win);

      /* update MPI-3 shared memory by writing data values  into shar_mem */

    shar_mem[0] = (rank+1)*100; 

    MPI_Win_fence (0, win); 


    for (j=0; j<n_partners; j++) 
    {
      if(maps_shm[j] != MPI_UNDEFINED) /* partner j is on the same node  */ 
      {
        halo[j] = shar_pntr[j][0]; /* load from MPI-3/SHM ops! */
        if(j == 0)
        printf ("from on-node leftside partner to rank= %d : value= %d\n", rank,halo[j]); 
        else
        printf ("from on-node rightside partner to rank= %d : value= %d\n", rank,halo[j]); 
      }
      else /* inter-node non-blocking MPI-1 */
      {
        MPI_Irecv (&halo[j], 1, MPI_INT, partners[j], 1 , comm, rq++);
        MPI_Isend (&shar_mem[0], 1, MPI_INT, partners[j], 1 , comm, rq++);
      }
    } 

   /* sync inter-node exchanges and print out receive buffer ibuf*/
   if(off_node_partners > 0)
   {
     MPI_Waitall (req_num*off_node_partners, reqs, MPI_STATUS_IGNORE); 
     {
       for (j =0; j< n_partners;j++)
       if (maps_shm[j] == MPI_UNDEFINED )
        if(j == 0)
       printf("from off-node leftside partner to rank = %d : value= %d\n", rank,halo[j]);
        else
       printf("from off_node rightside partner to rank = %d : value= %d\n", rank,halo[j]);
     }
   }    
        printf (" on rank= %d : leftside=  %d : midpt= %d : rightside= %d\n", rank, halo[0],shar_mem[0],halo[1]);

   /* free resources */
   MPI_Win_free (&win);
   free (shar_pntr); 
   
   if (off_node_partners) free (reqs);
   
   free (maps_shm);  
   
   MPI_Finalize ();

   return (0);
 }


