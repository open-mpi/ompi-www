#!/bin/bash
ulimit -s unlimited
echo "This is from mpi.sh"
pwd
mpirun -np 4  -machinefile nodelist ./mpi_subprog
