#!/bin/bash
ulimit -s unlimited
echo "This is from serial.sh"
./serial_subprog
