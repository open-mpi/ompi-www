
   #include <sys/time.h>
   #include <stdio.h>
   #include <math.h>

   #include <mpi.h>

   #include "counter.h"

   #define  MPI_P2P_TAG    99

   int main
   (
       int argc,
       char **argv
   )
   {
       int rc, me, size;
       double start, end;
       double *A;
       MPI_Status status;
       char pname[MPI_MAX_PROCESSOR_NAME];
       int plen;

       A = (double*)malloc(
                    sizeof(double)
                    *
                    N*N
       );

       MPI_Init(
          &argc,
          &argv
       );

       MPI_Comm_rank(
          MPI_COMM_WORLD,
          &me
       );

       MPI_Comm_size(
          MPI_COMM_WORLD, 
          &size
       );

       MPI_Get_processor_name(
          pname,
          &plen
       );

       printf("PING: me=%d, my processor=%s\n", me, pname);

       start = MPI_Wtime();

       if (me == 0)
       {
          rc = MPI_Send(
                  A,
                  N*N,
                  MPI_DOUBLE,
                  1,
                  MPI_P2P_TAG,
                  MPI_COMM_WORLD
          );

	  if (rc != MPI_SUCCESS)
          {
             printf("0->1 failed\n");
	  }	   

          rc = MPI_Recv(
                  A,
                  N*N,
                  MPI_DOUBLE,
                  1,
                  MPI_P2P_TAG,
                  MPI_COMM_WORLD,
                  &status
          );

	  if (rc != MPI_SUCCESS)
          {
             printf("1->0 failed, status error code=%d\n", status.MPI_ERROR);
	  }	   
       }

       if (me == 1)
       {
          rc = MPI_Recv(
                  A,
                  N*N,
                  MPI_DOUBLE,
                  0,
                  MPI_P2P_TAG,
                  MPI_COMM_WORLD,
                  &status
          );

	  if (rc != MPI_SUCCESS)
          {
             printf("0->1 failed, status error code=%d\n", status.MPI_ERROR);
	  }	   

          rc = MPI_Send(
                  A,
                  N*N,
                  MPI_DOUBLE,
                  0,
                  MPI_P2P_TAG,
                  MPI_COMM_WORLD
          );

	  if (rc != MPI_SUCCESS)
          {
             printf("1->0 failed\n");
	  }	   
       }

       end = MPI_Wtime();

       if (me == 0)
       {
	 double t_sec    = (end - start);
         double nbytes   = (N*N*8)*2;
         double onekb    = 1024;
         int nkb         = nbytes/onekb;
 
         printf(
           "N(KB)=%d, t(sec)=%0.6f\n",
           nkb,
           t_sec
         );
       } 

       free(A);

       MPI_Finalize();
   }

