#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* some bogus user code that just allocates memory */

void foo2(void **ptr, int me) {
  *ptr = malloc(1024 * 1024 * 128 * me);
}

void foo1(void **ptr, int me) {
  foo2(ptr, me);
}

/* main function */

int main(int argc, char **argv)
{
  int me, np, i, n = 1000000, nsleep = 0, buf = - 1;
  void *ptr;

  /* find out how long receiver should sleep */

  if ( argc > 1 ) {
    nsleep = atoi(argv[1]);
  }

  /* initialize MPI */

  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &np);
  MPI_Comm_rank(MPI_COMM_WORLD, &me);

  /* have user program allocate some memory just for the fun of it */

  foo1(&ptr, me);

  /* have rank 0 send rank 1 lots of messages, but have rank 1 sleep first */

  if ( me == 0 ) {
    for ( i = 0; i < n; i++ )
      MPI_Send(&buf, 1, MPI_INT, 1, 343, MPI_COMM_WORLD                   );
  } else {
    sleep(nsleep);
    for ( i = 0; i < n; i++ )
      MPI_Recv(&buf, 1, MPI_INT, 0, 343, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  }

  free(ptr);
  MPI_Finalize();
  return 0;
}

