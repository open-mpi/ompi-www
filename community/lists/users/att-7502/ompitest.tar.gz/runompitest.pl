#!/usr/bin/env perl

$MPIHOME = "/home/dorian/devel64/openmpi-1.2.8-gcc-4.3.2";
$MPICXX  = "$MPIHOME" . "/bin/mpicxx";
$MPIEXEC = "$MPIHOME" . "/bin/mpiexec";
@FLAGS0  = ("-DO1=1", "-DO2=1");
@FLAGS1  = ("-DV1=1", "-DV2=1");

foreach (@FLAGS0) {
	$flag0 = $_;

	foreach (@FLAGS1) {
		$flag1 = $_;

		print "*** $flag0 $flag1 ***\n";
		system "$MPICXX -DONESIDED $flag0 $flag1 ompitest.cc";
		system "$MPIEXEC -np 2 ./a.out"
	}
}
