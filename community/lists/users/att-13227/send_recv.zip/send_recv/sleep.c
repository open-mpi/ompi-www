#include <stdio.h>
#include <unistd.h>
 
/* This function is accurate to milliseconds */
void usleep_fortran_( double *time ) {
  int sec, i;

  sec = *time;
  for (i=1; i<=sec; i++) {
    usleep(1000000);
  }
  sec = (*time-sec)*1000000;

  usleep(sec);
}