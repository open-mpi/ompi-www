#!/bin/bash

# Script to exemplify behaviour of OpenMPI when a subsequent "tail -f" is
# INTerrupted. Run './ompi_bug mpi' and './ompi_bug nompi'.  Both will start
# a simple counting script in the background, one with mpirun and the other
# one without, and tail it.  Pressing Ctrl+C before the counter reaches 10
# should stop tail but not the background job.  This works without mpirun,
# but fails to work without, no matter if you try your best nohup/disown/
# subshell/recursive-script-calling tricks.

SCRIPT="i=0 ; while ((i<10)) ; do i=\$((i+1)) ; sleep 1 ; echo \$i ; done ;\
 echo Done"

# Read mode from cmd line
mode="$1"
case "$mode" in
mpi|nompi)
  ;;
"")
  mode=mpi ;;
*)
  echo "Usage: ${0##*/} [mpi|nompi]" ; exit 1 ;;
esac
out=./output.$mode
rm -f "$out"
echo "$mode:" > "$out"

# Run in requested mode in the background
case "$mode" in
mpi)
  mpirun -np 1 bash -c "$SCRIPT" >> "$out" 2>&1 &
  ;;
nompi)
  bash -c "$SCRIPT" >> "$out" 2>&1 &
  ;;
esac

# Tail the output
tail -f "$out"
