#!/usr/bin/env python
from distutils.core import setup
from distutils.extension import Extension

setup(
	name='minimpi',
	version='0.0.2',
	description='MPI-wrapper to allow early calls to MPI_Init() and MPI_Finalize())',
	author='Daniel Vollmer',
	author_email='daniel.vollmer@dlr.de',
	py_modules=['minimpi'],
	ext_modules=[Extension('minimpiext', ['minimpiext.c'],
		include_dirs=['/usr/local/include'],
		library_dirs=['/usr/local/lib'],
		libraries=['mpi']
	)]
)

