#include <Python.h>
#include <mpi.h>
/*#include <stdlib.h>

static void mpiexitfunc(void)
{
	int	error, init, fin = 0;

	error = MPI_Initialized(&init);
	error = !error && MPI_Finalized(&fin);
	if (error == 0 && init != 0 && fin == 0)
		error = MPI_Finalize();
}*/

static PyObject* init(PyObject *self, PyObject *args)
{
	PyObject *input;
	char **argv;
	int i, error, argc = 0;

	/* ask for a list-object as argument */
	if (!PyArg_ParseTuple(args, "O!", &PyList_Type, &input))
		return NULL;

	/* reconstruct C-commandline */
	argc = PyList_Size(input); /* # of commandline arguments */
	argv = (char **)PyMem_Malloc((argc+1) * sizeof *argv);

	for (i = 0; i < argc; i++)
		argv[i] = PyString_AsString(PyList_GetItem(input, i));

	argv[i] = NULL; /* Lam 7.0 requires last arg to be NULL */

	error = MPI_Init(&argc, &argv);
	if (error != 0)
	{
     	int errlen;
		char errmsg[MPI_MAX_ERROR_STRING];

		MPI_Error_string(error, errmsg, &errlen);
		PyErr_SetString(PyExc_RuntimeError, errmsg);
		PyMem_Free(argv);
		return NULL;
	}
	else
	{ /* So if we managed the init, we create an updated argv to return */
		PyObject *result = PyList_New(argc);

		for (i = 0; i < argc; i++)
			PyList_SetItem(result, i, PyString_FromString(argv[i]));
		PyMem_Free(argv);
//		atexit(mpiexitfunc); /* because Python calls its atexit() too early :( */
		return result;
	}
}

static PyObject* initialized(PyObject *self, PyObject *args)
{
	int	error, flag = 0;

	error = MPI_Initialized(&flag);
	if (error != 0)
	{
     	int errlen;
		char errmsg[MPI_MAX_ERROR_STRING];

		MPI_Error_string(error, errmsg, &errlen);
		PyErr_SetString(PyExc_RuntimeError, errmsg);
		return NULL;
	}
	return PyBool_FromLong(flag);
}

static PyObject* finalize(PyObject *self, PyObject *args)
{
	int	error;

	error = MPI_Finalize();
	if (error != 0)
	{
     	int errlen;
		char errmsg[MPI_MAX_ERROR_STRING];

		MPI_Error_string(error, errmsg, &errlen);
		PyErr_SetString(PyExc_RuntimeError, errmsg);
		return NULL;
	}
	Py_RETURN_TRUE;
}


static struct PyMethodDef MethodTable[] =
{
	{"finalize", finalize, METH_VARARGS, PyDoc_STR("finalize() -> None\nCalls MPI_Finalize().")},
	{"init", init, METH_VARARGS, PyDoc_STR("init(argv) -> newargv\nCalls MPI_Init() with the given argv and returns an updated argv on success.")},
	{"initialized", initialized, METH_VARARGS, PyDoc_STR("initialized() -> bool\nCalls MPI_Initialized() and returns the status.")},
	{NULL, NULL, 0, NULL}
};

PyDoc_STRVAR(module_doc, "This module provides calls perform MPI initialization and finalization.");

PyMODINIT_FUNC initminimpiext(void)
{
	Py_InitModule3("minimpiext", MethodTable, module_doc);
}
