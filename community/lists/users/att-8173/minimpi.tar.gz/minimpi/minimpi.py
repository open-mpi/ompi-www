"""Minimal MPI wrapper that allows for an early MPI initialization.

MPI-Initialization is done on import. MPI_Finalize() is called via atexit.

Changelog:
0.0.0 -> 0.0.1:
- first release

0.0.1 -> 0.0.2:
- introduced many more checks before calling functions on the FSClacs in _finalize()
"""

try:
	import minimpiext
except ImportError: # couldn't load the .so
	import os
	
	if not os.environ.has_key('PYTHON_MPI_INIT'):
		raise RuntimeError('Unable to import minimpiext and PYTHON_MPI_INIT is not set (i.e. no-one else is doing our job)!')
	# otherwise we assume that the patched python-binary has performed the init
else: # we managed to load the .so
	if not minimpiext.initialized():
		import sys, atexit
		
		sys.argv = minimpiext.init(sys.argv) # on error, we raise a RuntimeError
		def _finalize():
			# work-around to make sure all communicators are freed before we call MPI_Finalize()
			import gc
			allcomms = [x for x in gc.get_objects() if hasattr(x, 'sSelfComm') and hasattr(x, 'SetCommunicator') and callable(x.SetCommunicator) and str(type(x)).find('FSClac') >= 0]
			for x in allcomms:
				x.SetCommunicator(x.sSelfComm) # this frees the previously used communicator, which is what we want
			del x
			del allcomms
			minimpiext.finalize()
		atexit.register(_finalize)
