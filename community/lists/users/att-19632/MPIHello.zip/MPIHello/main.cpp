/* test of MPI */  
#include "mpi.h"  
#include <stdio.h>  
#include <string.h>  

int main(int argc, char **argv)  
{  
	char idstr[2232]; char buff[22128];  
	char processor_name[MPI_MAX_PROCESSOR_NAME];  
	int numprocs; int myid; int i; int namelen;  
	MPI_Status stat;  

	MPI_Init(&argc,&argv);  
	MPI_Comm_size(MPI_COMM_WORLD,&numprocs);  
	MPI_Comm_rank(MPI_COMM_WORLD,&myid);  
	MPI_Get_processor_name(processor_name, &namelen);  

	if(myid == 0)  
	{  
		printf("WE have %d processors\n", numprocs);  
		for(i=1;i<numprocs;i++)  
		{  
			sprintf(buff, "Hello %d", i);  
			MPI_Send(buff, 128, MPI_CHAR, i, 0, MPI_COMM_WORLD); }  
		for(i=1;i<numprocs;i++)  
		{  
			MPI_Recv(buff, 128, MPI_CHAR, i, 0, MPI_COMM_WORLD, &stat);  
			printf("%s\n", buff);  
		}  
	}  
	else  
	{   
		MPI_Recv(buff, 128, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &stat);  
		sprintf(idstr, " Processor %d at node %s ", myid, processor_name);  
		strcat(buff, idstr);  
		strcat(buff, "reporting for duty\n");  
		MPI_Send(buff, 128, MPI_CHAR, 0, 0, MPI_COMM_WORLD);  
	}  
	MPI_Finalize();  

}  