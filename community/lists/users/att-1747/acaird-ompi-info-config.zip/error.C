#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

int main(int argc,char **argv) {

  int ThisThread=0;
  int TotalThreadsNumber=1;

printf("asdasdas\n");

MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD,&ThisThread);
  MPI_Comm_size(MPI_COMM_WORLD,&TotalThreadsNumber);

  MPI_Finalize();
  return 1;
}
