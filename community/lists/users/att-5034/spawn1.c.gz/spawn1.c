
#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PROCS   2

int
main (int argc, char *argv[])
{
  int i;
  int np = MAX_PROCS;
  MPI_Comm parentcomm, intercomm[MAX_PROCS];

  MPI_Init (&argc, &argv);
  MPI_Comm_get_parent (&parentcomm);

  if (parentcomm == MPI_COMM_NULL)
    {
      printf ("spawning ... \n");
      for (i= 0; i < np; i++) 
      {
      MPI_Comm_spawn ("./spawn1", MPI_ARGV_NULL, 1,
		      MPI_INFO_NULL, 0, MPI_COMM_SELF, &intercomm[i], MPI_ERRCODES_IGNORE);
      }
    }
  else 
    printf ("child!\n");

  MPI_Finalize ();
  return 0;
}
