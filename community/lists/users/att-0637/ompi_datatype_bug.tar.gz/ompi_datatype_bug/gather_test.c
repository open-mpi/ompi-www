/*============================================================================
 * Simple test based on functions related to the gathering of local
 * arrays based on global ranks in parallel mode.
 *
 * This is extracted from EDF's "Finite Volume Mesh" library, used to
 * handle I/O of mesh connectivity and filed data to and in the future
 * from different file formats (and not currently relying on MPI-IO,
 * as many MPI-2 features are still unavailable on many supercomputers,
 * though we hope Open MPI and MPICH2 will change this).
 *
 * The following code has been simplified compared to the original
 * code (which works with slices to avoid excessive memory use
 * on rank 0, and uses MPI_hindexed datatypes instead of MPI_indexed),
 * but a problem observed with Open MPI still seems to be reproducible
 * with this example, which should be run on 2 processors:
 *
 * Each processor reads a file ("data_p0" or "data_p1") giving
 * a list of global element ids. Some elements (vertices from a partitionned
 * mesh) may belong to both processors, so their id's may appear on both
 * processors: we have 7178 global vertices, 3654 and 3688 of them being
 * known by ranks 0 and 1 respectively.
 * In this simplified version, we assign coordinates {x, y, z} to each
 * vertex equal to it's global id number for rank 1, and the negative
 * of that for rank 0 (assigning the same values to x, y, and z).
 * After finishing the "ordered gather", rank 0 prints the global id
 * and coordinates of each vertex.
 *
 * lines should print (for example) as:
 *   6456 ;   6455.00000   6455.00000   6456.00000
 *   6457 ;  -6457.00000  -6457.00000  -6457.00000
 * depending on whether a vertex belongs only to rank 0 (negative
 * coordinates) or belongs to rank 1 (positive coordinates).
 *
 * With the OMPI 1.0.1 bug (observed on Suse Linux 10.0 with gcc 4.0
 * and on Debian sarge with gcc 3.4), we have for example for the last
 * vertices:
 *  7176 ;   7175.00000   7175.00000   7176.00000
 *  7177 ;   7176.00000   7176.00000   7177.00000
 * seeming to indicate an "off by one" type bug in datatype handling
 *
 * Not using an indexed datatype (i.e. not defining USE_INDEXED_DATATYPE
 * below), the bug dissapears. Using the indexed datatype with
 * LAM MPI 7.1.1 or MPICH2, we do not reproduce the bug either,
 * so it does seem to be an Open MPI issue.
 *
 * As the parent library is expected to be released under the LGPL
 * licence, this code may also be distributed under the LGPL licence,
 * version 2.
 *                                                          Copyright EDF 2006
 *============================================================================*/

/*----------------------------------------------------------------------------
 * Standard C library headers
 *----------------------------------------------------------------------------*/

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

#include <mpi.h>

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#if 0
} /* Fake brace to force back Emacs auto-indentation back to column 0 */
#endif
#endif /* __cplusplus */

/*============================================================================
 * Macros
 *============================================================================*/

#define USE_INDEXED_DATATYPE 1

#define MALLOC(_ptr, _ni, _type) \
{ _ptr = (_type *) malloc((_ni) * sizeof(_type)); \
 if (_ptr == NULL) exit(1);}

#define TAG 1234

/*=============================================================================
 * Private function definitions
 *============================================================================*/

/*----------------------------------------------------------------------------
 * Gather a given portion of an array to rank 0.
 *
 * parameters:
 *   local_array       <-- local array (size n_local_elements * stride)
 *   global_array      --> global array for elements
 *                         (output for rank 0, working array only for others)
 *   stride            <-- number of (interlaced) values per element
 *   local_size        <-- local number of entities
 *   global_size       <-- global number of entities
 *   global_id         <-- global id associated with elements (0 to n-1)
 *   comm              <-- MPI communicator for structures considered
 *----------------------------------------------------------------------------*/

void
fvm_gather_array(const double        *local_array,
                 double              *global_array,
                 const size_t         stride,
                 const size_t         local_size,
                 const size_t         global_size,
                 const unsigned       global_id[],
                 MPI_Comm             comm)
{
  int  distant_size;
  size_t  i, j;

  /* MPI related variables */

  MPI_Status  status;
  MPI_Datatype  fvm_index_type;
  int distant_rank;
  int local_rank;
  int n_ranks;
  int *blocklengths = NULL;
  int *displacements = NULL;

  /* Get info on the current MPI communicator */
  MPI_Comm_rank(comm, &local_rank);
  MPI_Comm_size(comm, &n_ranks);

  /* Initialize blocklengths and displacements */

  if (local_rank == 0) {
    MALLOC(blocklengths, global_size, int);
  }
  MALLOC(displacements, global_size,  int);

  if (local_rank == 0) {
    for (i = 0 ; i < global_size ; i++)
      blocklengths[i] = stride;
  }

  for (i = 0;
       (i < local_size && global_id[i] < global_size) ;
       i++) {
    displacements[i] = global_id[i] * stride;
  }

  assert(i == local_size);

  /*
    Prepare send buffer:
    For rank 0, set final values directly.
  */

  if (local_rank == 0) {
    for (i = 0 ; i < local_size ; i++) {
      for (j = 0 ; j < stride ; j++) {
        global_array[displacements[i] + j] = local_array[i*stride + j];
      }
    }
  }
  else {
    for (i = 0 ; i < local_size ; i++) {
      for (j = 0 ; j < stride ; j++)
        global_array[i*stride + j] = local_array[i*stride + j];
    }
  }

  /* Gather connectivity information from ranks > 0 */

  if (local_rank == 0) {

    for (distant_rank = 1 ; distant_rank < n_ranks ; distant_rank++) {

      /* Get index from distant rank */

      MPI_Probe(distant_rank, TAG, comm, &status);
      MPI_Get_count(&status, MPI_INT, &distant_size);

      MPI_Recv(displacements, distant_size, MPI_INT,
               distant_rank, TAG, comm, &status);

      if (distant_size > 0) {

#ifdef USE_INDEXED_DATATYPE

        /*
          Define indexed datatype so as to directly receive
          to correct location
        */

        MPI_Type_indexed(distant_size, blocklengths, displacements,
                         MPI_DOUBLE, &fvm_index_type);
        MPI_Type_commit(&fvm_index_type);

        /* Get portion of connectivity array from distant rank */

        MPI_Recv(global_array, 1, fvm_index_type,
                 distant_rank, TAG, comm, &status);

        MPI_Type_free(&fvm_index_type);

#else

        /* Version without datatype, always works */

        double *recv_buf;
        MALLOC(recv_buf, distant_size*stride, double);

        MPI_Recv(recv_buf, distant_size*stride, MPI_DOUBLE,
                 distant_rank, TAG, comm, &status);

        for (i = 0 ; i < distant_size ; i++) {
          for (j = 0 ; j < stride ; j++) {
            global_array[displacements[i] + j]
              = recv_buf[i*stride + j];
          }
        }

        free(recv_buf);

#endif

      }

    }

  }
  else {

    /* Send local index to rank zero */

    MPI_Send(displacements, (int)local_size, MPI_INT, 0,
             TAG, comm);

    /* Send local portion of connectivity array to rank zero */

    if (local_size > 0)
      MPI_Send(global_array, (int)(local_size * stride),
               MPI_DOUBLE, 0, TAG, comm);

  }

#if 0 && defined(DEBUG) && !defined(NDEBUG)
  MPI_Barrier(comm);
#endif

}

/*----------------------------------------------------------------------------*/

int main(int    argc,
         char  *argv[])
{
  int i, ret, gn;
  int comm_size;
  int comm_rank;
  FILE *f;

  char *s;
  char *file_name[] = {"data_p0", "data_p1"};
  int local_size[] = {3654, 3688};
  unsigned global_size = 7178;

  unsigned  *global_num = NULL;
  double *coords = NULL;
  double *global_coords = NULL;

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &comm_rank);
  MPI_Comm_size(MPI_COMM_WORLD, &comm_size);

  assert(comm_size == 2);

  /* Read file data */

  MALLOC(global_num, local_size[comm_rank], unsigned);
  MALLOC(coords, local_size[comm_rank]*3, double);

  f = fopen(file_name[comm_rank], "r");

  for (i = 0; i < local_size[comm_rank]; i++) {
    ret = fscanf(f, "%d", &gn);
    if (ret != 1) {
      fprintf(stderr, "rank %d: error reading data file\n", comm_rank);
      exit(1);
    }
    global_num[i] = gn - 1;
    if (comm_rank == 1) {
      coords[i*3]   = global_num[i];
      coords[i*3+1] = global_num[i];
      coords[i*3+2] = global_num[i];
    }
    else { /* if (comm_rank == 0) */
      coords[i*3]   = -1.0 * global_num[i];
      coords[i*3+1] = -1.0 * global_num[i];
      coords[i*3+2] = -1.0 * global_num[i];
    }
  }

  fclose(f);

  MALLOC(global_coords, global_size * 3, double);

  fvm_gather_array(coords,
                   global_coords,
                   3,
                   local_size[comm_rank],
                   global_size,
                   global_num,
                   MPI_COMM_WORLD);

  if (comm_rank == 0) {
    for (i = 0; i < global_size; i++) {
      printf("%10d ; %12.5f %12.5f %12.5f\n",
             i,
             global_coords[i*3],
             global_coords[i*3 + 1],
             global_coords[i*3 + 2]);
    }
  }

  free(global_coords);

  MPI_Finalize();
  exit(0);
}
#ifdef __cplusplus
}
#endif /* __cplusplus */
