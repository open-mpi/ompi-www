#include <stdio.h>
#include <stdlib.h>

void
SIZE(char *a, char *b)
{
   int diff = (int) (b - a);
   printf("size is %d\n", diff);
}
