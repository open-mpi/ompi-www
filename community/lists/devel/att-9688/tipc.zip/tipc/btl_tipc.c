/*
 * Copyright (c) 2011      Ericsson AB. All rights reserved.
 * Copyright (c) 2004-2007 The Trustees of Indiana University and Indiana
 *                         University Research and Technology
 *                         Corporation.  All rights reserved.
 * Copyright (c) 2004-2009 The University of Tennessee and The University
 *                         of Tennessee Research Foundation.  All rights
 *                         reserved.
 * Copyright (c) 2004-2005 High Performance Computing Center Stuttgart, 
 *                         University of Stuttgart.  All rights reserved.
 * Copyright (c) 2004-2005 The Regents of the University of California.
 *                         All rights reserved.
 * Copyright (c) 2010      Cisco Systems, Inc.  All rights reserved.
 * $COPYRIGHT$
 * 
 * Additional copyrights may follow
 * 
 * $HEADER$
 */

#include "ompi_config.h"
#include <string.h>
#include "opal/class/opal_bitmap.h"
#include "ompi/mca/btl/btl.h"

#include "btl_tipc.h"
#include "btl_tipc_frag.h" 
#include "btl_tipc_proc.h"
#include "btl_tipc_endpoint.h"
#include "opal/datatype/opal_convertor.h" 
#include "ompi/mca/mpool/base/base.h" 
#include "ompi/mca/mpool/mpool.h" 
#include "ompi/proc/proc.h"
#define MCA_BTL_HAS_MPOOL 1

/*Start of connection*/
mca_btl_tipc_module_t mca_btl_tipc_module = {
    {
        &mca_btl_tipc_component.super,
        0, /* max size of first fragment */
        0, /* min send fragment size */
        0, /* max send fragment size */
        0, /* rdma pipeline offset */
        0, /* rdma pipeline frag size */
        0, /* min rdma pipeline size */
        0, /* exclusivity */
        0, /* latency */
        0, /* bandwidth */
        0, /* flags */
        mca_btl_tipc_add_procs,
        /*
                mca_btl_tipc_del_procs,
         */
        NULL, /*mca_btl_tipc_del_procs,*/
        NULL, /*mca_btl_tipc_register*/
        mca_btl_tipc_finalize,
        mca_btl_tipc_alloc,
        mca_btl_tipc_free,
        mca_btl_tipc_prepare_src,
        mca_btl_tipc_prepare_dst,
        mca_btl_tipc_send,
        NULL, /* send immediate */
        NULL, /*mca_btl_tipc_put,*/
        NULL, /* get */
        NULL, /*dump */
        NULL, /* mpool */
        NULL, /* register error cb */
        mca_btl_tipc_ft_event
    }
};

int mca_btl_tipc_add_procs(
        struct mca_btl_base_module_t* btl,
        size_t nprocs,
        struct ompi_proc_t **ompi_procs,
        struct mca_btl_base_endpoint_t** peers,
        opal_bitmap_t* reachable) {

    DEBUG_INFO("mca_btl_tipc_add_procs\n");
    mca_btl_tipc_module_t* tipc_btl = (mca_btl_tipc_module_t*) btl;
    ompi_proc_t* my_proc; /* pointer to caller's proc structure */
    int i, rc;

    /* get pointer to my proc structure */
    my_proc = ompi_proc_local();
    if (NULL == my_proc) {
        return OMPI_ERR_OUT_OF_RESOURCE;
    }

    for (i = 0; i < (int) nprocs; i++) {


        struct ompi_proc_t* ompi_proc = ompi_procs[i];
        mca_btl_tipc_proc_t* tipc_proc;
        mca_btl_base_endpoint_t* tipc_endpoint;

        /* Do not create loopback tipc connections */
        if (my_proc == ompi_proc) {
            continue;
        }

        if (NULL == (tipc_proc = mca_btl_tipc_proc_create(ompi_proc))) {
            return OMPI_ERR_OUT_OF_RESOURCE;
        }

        /*
         * Check to make sure that the peer has at least as many interface 
         * addresses exported as we are trying to use. If not, then 
         * don't bind this BTL instance to the proc.
         */

        OPAL_THREAD_LOCK(&tipc_proc->proc_lock);

        /* The btl_proc datastructure is shared by all tipc BTL
         * instances that are trying to reach this destination. 
         * Cache the peer instance on the btl_proc.
         */
        tipc_endpoint = OBJ_NEW(mca_btl_tipc_endpoint_t);
        if (NULL == tipc_endpoint) {
            OPAL_THREAD_UNLOCK(&tipc_proc->proc_lock);
            return OMPI_ERR_OUT_OF_RESOURCE;
        }

        /*get peer address*/
        /*
                tipc_endpoint->endpoint_addr = (struct sockaddr_tipc *)malloc(sizeof(struct sockaddr_tipc));
                memcpy(tipc_endpoint->endpoint_addr,peers[i]->endpoint_addr,sizeof(struct sockaddr_tipc));
         */
        /*
                tipc_endpoint->endpoint_addr = peers[0]->endpoint_addr;
         */

        tipc_endpoint->endpoint_btl = tipc_btl;

        rc = mca_btl_tipc_proc_insert(tipc_proc, tipc_endpoint);

        if (rc != OMPI_SUCCESS) {
            OPAL_THREAD_UNLOCK(&tipc_proc->proc_lock);
            OBJ_RELEASE(tipc_endpoint);
            continue;
        }

        opal_bitmap_set_bit(reachable, i);
        OPAL_THREAD_UNLOCK(&tipc_proc->proc_lock);
        peers[i] = tipc_endpoint;


        opal_list_append(&tipc_btl->tipc_endpoints, (opal_list_item_t*) tipc_endpoint);

        /* we increase the count of MPI users of the event library
           once per peer, so that we are used until we aren't
           connected to a peer */
        opal_progress_event_users_increment();
    }

    return OMPI_SUCCESS;

}

int mca_btl_tipc_del_procs(struct mca_btl_base_module_t* btl,
        size_t nprocs,
        struct ompi_proc_t **procs,
        struct mca_btl_base_endpoint_t ** peers) {
    /* TODO */
    DEBUG_INFO("mca_btl_tipc_del_procs\n");
    return OMPI_SUCCESS;
}

mca_btl_base_descriptor_t* mca_btl_tipc_alloc(
        struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* endpoint, uint8_t order, size_t size,
        uint32_t flags) {
/*
    DEBUG_INFO("mca_btl_tipc_alloc\n");
*/
    mca_btl_tipc_frag_t* frag = NULL;
    int rc;
    if (size <= btl->btl_eager_limit) {
        MCA_BTL_TIPC_FRAG_ALLOC_EAGER(frag, rc);
    } else if (size <= btl->btl_max_send_size) {
        MCA_BTL_TIPC_FRAG_ALLOC_MAX(frag, rc);
    }
    if (OPAL_UNLIKELY(NULL == frag)) {
        return NULL;
    }

    frag->segments[0].seg_len = size;
    frag->segments[0].seg_addr.pval = frag + 1;
    frag->base.des_src = frag->segments;
    frag->base.des_src_cnt = 1;
    frag->base.des_dst = NULL;
    frag->base.des_dst_cnt = 0;
    frag->base.des_flags = flags;
    frag->base.order = MCA_BTL_NO_ORDER;
    frag->btl = (mca_btl_tipc_module_t*) btl;
    return (mca_btl_base_descriptor_t*) frag;
}

int mca_btl_tipc_free(struct mca_btl_base_module_t* btl,
        mca_btl_base_descriptor_t* des) {
    DEBUG_INFO("mca_btl_tipc_free");
    mca_btl_tipc_frag_t* frag = (mca_btl_tipc_frag_t*) des;
    MCA_BTL_TIPC_FRAG_RETURN(frag);
    return OMPI_SUCCESS;
}

mca_btl_base_descriptor_t* mca_btl_tipc_prepare_src(
        struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* peer,
        struct mca_mpool_base_registration_t*registration,
        struct opal_convertor_t* convertor,
        uint8_t order,
        size_t reserve,
        size_t* size,
        uint32_t flags
        ) {
/*
    DEBUG_INFO("mca_btl_tipc_prepare_src\n");
*/
    mca_btl_tipc_frag_t* frag;
    struct iovec iov;
    uint32_t iov_count = 1;
    size_t max_data = *size;
    int rc;

    if (OPAL_UNLIKELY(max_data > UINT32_MAX)) { /* limit the size to what we support */
        max_data = (size_t) UINT32_MAX;
    }
    /*
     * if we aren't pinning the data and the requested size is less
     * than the eager limit pack into a fragment from the eager pool
     */
    if (max_data + reserve <= btl->btl_eager_limit) {
        MCA_BTL_TIPC_FRAG_ALLOC_EAGER(frag, rc);
    } else {
        /* 
         * otherwise pack as much data as we can into a fragment
         * that is the max send size.
         */
        MCA_BTL_TIPC_FRAG_ALLOC_MAX(frag, rc);
    }
    if (OPAL_UNLIKELY(NULL == frag)) {
        return NULL;
    }

    frag->segments[0].seg_addr.pval = (frag + 1);
    frag->segments[0].seg_len = reserve;

    frag->base.des_src_cnt = 1;
    if (opal_convertor_need_buffers(convertor)) {

        if (max_data + reserve > frag->size) {
            max_data = frag->size - reserve;
        }
        iov.iov_len = max_data;
        iov.iov_base = (IOVBASE_TYPE*) (((unsigned char*) (frag->segments[0].seg_addr.pval)) + reserve);

        rc = opal_convertor_pack(convertor, &iov, &iov_count, &max_data);
        if (OPAL_UNLIKELY(rc < 0)) {
            mca_btl_tipc_free(btl, &frag->base);
            return NULL;
        }

        frag->segments[0].seg_len += max_data;

    } else {

        iov.iov_len = max_data;
        iov.iov_base = NULL;

        rc = opal_convertor_pack(convertor, &iov, &iov_count, &max_data);
        if (OPAL_UNLIKELY(rc < 0)) {
            mca_btl_tipc_free(btl, &frag->base);
            return NULL;
        }

        frag->segments[1].seg_addr.pval = iov.iov_base;
        frag->segments[1].seg_len = max_data;
        frag->base.des_src_cnt = 2;
    }

    frag->base.des_src = frag->segments;
    frag->base.des_dst = NULL;
    frag->base.des_dst_cnt = 0;
    frag->base.des_flags = flags;
    frag->base.order = MCA_BTL_NO_ORDER;
    *size = max_data;
    return &frag->base;
}

mca_btl_base_descriptor_t* mca_btl_tipc_prepare_dst(
        struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* peer,
        struct mca_mpool_base_registration_t* registration,
        struct opal_convertor_t* convertor,
        uint8_t order,
        size_t reserve,
        size_t* size,
        uint32_t flags) {

    DEBUG_INFO("mca_btl_tipc_prepare_dst\n");
    mca_btl_tipc_frag_t* frag;
    int rc;

    if (OPAL_UNLIKELY((*size) > UINT32_MAX)) { /* limit the size to what we support */
        *size = (size_t) UINT32_MAX;
    }
    MCA_BTL_TIPC_FRAG_ALLOC_USER(frag, rc);
    if (OPAL_UNLIKELY(NULL == frag)) {
        printf("prepare dst failed\n");
        return NULL;
    }

    frag->segments->seg_len = *size;
    opal_convertor_get_current_pointer(convertor, (void**) &(frag->segments->seg_addr.pval));

    frag->base.des_src = NULL;
    frag->base.des_src_cnt = 0;
    frag->base.des_dst = frag->segments;
    frag->base.des_dst_cnt = 1;
    frag->base.des_flags = flags;
    frag->base.order = MCA_BTL_NO_ORDER;
    return &frag->base;
}

int mca_btl_tipc_ft_event(int state) {
    DEBUG_INFO("mca_btl_tipc_ft_event\n");
    if (OPAL_CRS_CHECKPOINT == state) {
        ;
    } else if (OPAL_CRS_CONTINUE == state) {
        ;
    } else if (OPAL_CRS_RESTART == state) {
        ;
    } else if (OPAL_CRS_TERM == state) {
        ;
    } else {
        ;
    }

    return OMPI_SUCCESS;
}

int mca_btl_tipc_send(struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* endpoint,
        struct mca_btl_base_descriptor_t* descriptor, mca_btl_base_tag_t tag) {

/*
    DEBUG_INFO("mca_btl_tipc_send\n");
*/

    /*
        mca_btl_tipc_module_t* tipc_btl = (mca_btl_tipc_module_t*) btl;
        mca_btl_tipc_frag_t* frag = (mca_btl_tipc_frag_t*) descriptor;
        frag->endpoint = endpoint;
        return mca_btl_tipc_endpoint_send(endpoint, frag);
     */
    mca_btl_tipc_module_t* tipc_btl = (mca_btl_tipc_module_t*) btl;
    mca_btl_tipc_frag_t* frag = (mca_btl_tipc_frag_t*) descriptor;
    int i;

    frag->btl = tipc_btl;
    frag->endpoint = endpoint;
    frag->rc = 0;
    frag->iov_idx = 0;
    frag->iov_cnt = 1;
    frag->iov_ptr = frag->iov;
    frag->iov[0].iov_base = (IOVBASE_TYPE*) & frag->hdr;
    frag->iov[0].iov_len = sizeof (frag->hdr);
    frag->hdr.size = 0;
    for (i = 0; i < (int) frag->base.des_src_cnt; i++) {
        frag->hdr.size += frag->segments[i].seg_len;
        frag->iov[i + 1].iov_len = frag->segments[i].seg_len;
        frag->iov[i + 1].iov_base = (IOVBASE_TYPE*) frag->segments[i].seg_addr.pval;
        frag->iov_cnt++;
    }
    frag->hdr.base.tag = tag;
    frag->hdr.type = MCA_BTL_TIPC_HDR_TYPE_SEND;
    frag->hdr.count = 0;
    /*
        if (endpoint->endpoint_nbo) MCA_BTL_TCP_HDR_HTON(frag->hdr);
     */

    return mca_btl_tipc_endpoint_send(endpoint, frag);
}

int mca_btl_tipc_finalize(struct mca_btl_base_module_t* btl) {

    DEBUG_INFO("mca_btl_tipc_finalize\n");


    mca_btl_tipc_module_t* tipc_btl = (mca_btl_tipc_module_t*) btl;
    opal_list_item_t* item;
    for (item = opal_list_remove_first(&tipc_btl->tipc_endpoints);
            item != NULL;
            item = opal_list_remove_first(&tipc_btl->tipc_endpoints)) {
        mca_btl_tipc_endpoint_t *endpoint = (mca_btl_tipc_endpoint_t*) item;
        OBJ_RELEASE(endpoint);
        opal_progress_event_users_decrement();
    }
    free(tipc_btl);

    return OMPI_SUCCESS;
}


