/*
 * Copyright (c) 2011      Ericsson AB. All rights reserved.
 * Copyright (c) 2004-2007 The Trustees of Indiana University and Indiana
 *                         University Research and Technology
 *                         Corporation.  All rights reserved.
 * Copyright (c) 2004-2009 The University of Tennessee and The University
 *                         of Tennessee Research Foundation.  All rights
 *                         reserved.
 * Copyright (c) 2004-2005 High Performance Computing Center Stuttgart, 
 *                         University of Stuttgart.  All rights reserved.
 * Copyright (c) 2004-2005 The Regents of the University of California.
 *                         All rights reserved.
 * Copyright (c) 2010      Cisco Systems, Inc.  All rights reserved.
 * $COPYRIGHT$
 * 
 * Additional copyrights may follow
 * 
 * $HEADER$
 */


#include "ompi_config.h"

#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif
#ifdef HAVE_SYS_UIO_H
#include <sys/uio.h>
#endif
#ifdef HAVE_NET_UIO_H
#include <net/uio.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif  /* HAVE_UNISTD_H */

#include "opal/opal_socket_errno.h"
#include "ompi/mca/btl/base/btl_base_error.h"
#include "btl_tipc_frag.h" 
#include "btl_tipc_endpoint.h"

static void mca_btl_tipc_frag_common_constructor(mca_btl_tipc_frag_t* frag) {
    frag->base.des_src = NULL;
    frag->base.des_src_cnt = 0;
    frag->base.des_dst = NULL;
    frag->base.des_dst_cnt = 0;
}

static void mca_btl_tipc_frag_eager_constructor(mca_btl_tipc_frag_t* frag) {
    frag->size = mca_btl_tipc_module.super.btl_eager_limit;
    frag->my_list = &mca_btl_tipc_component.tipc_frag_eager;
    mca_btl_tipc_frag_common_constructor(frag);
}

static void mca_btl_tipc_frag_max_constructor(mca_btl_tipc_frag_t* frag) {
    frag->size = mca_btl_tipc_module.super.btl_max_send_size;
    frag->my_list = &mca_btl_tipc_component.tipc_frag_max;
    mca_btl_tipc_frag_common_constructor(frag);
}

static void mca_btl_tipc_frag_user_constructor(mca_btl_tipc_frag_t* frag) {
    frag->size = 0;
    frag->my_list = &mca_btl_tipc_component.tipc_frag_user;
    mca_btl_tipc_frag_common_constructor(frag);
}


OBJ_CLASS_INSTANCE(
        mca_btl_tipc_frag_t,
        mca_btl_base_descriptor_t,
        NULL,
        NULL);

OBJ_CLASS_INSTANCE(
        mca_btl_tipc_frag_eager_t,
        mca_btl_base_descriptor_t,
        mca_btl_tipc_frag_eager_constructor,
        NULL);

OBJ_CLASS_INSTANCE(
        mca_btl_tipc_frag_max_t,
        mca_btl_base_descriptor_t,
        mca_btl_tipc_frag_max_constructor,
        NULL);

OBJ_CLASS_INSTANCE(
        mca_btl_tipc_frag_user_t,
        mca_btl_base_descriptor_t,
        mca_btl_tipc_frag_user_constructor,
        NULL);

bool mca_btl_tipc_frag_send(mca_btl_tipc_frag_t* frag, int sd) {
/*
    DEBUG_INFO("mca_btl_tipc_frag_send");
*/
    int cnt = -1;
    size_t i, num_vecs;
    /* non-blocking write, but continue if interrupted */
    while (cnt < 0) {
        cnt = writev(sd, frag->iov_ptr, frag->iov_cnt);
        int i;
#if ENABLE_DEBUG_INFO & 0
        printf("Process: %d, Filename: %s, line: %d: %d\n", getpid(), __FILE__, __LINE__, frag->iov_cnt);
#endif
        if (cnt < 0) {
            switch (opal_socket_errno) {
                case EINTR:
                    continue;
                case EWOULDBLOCK:
                    return false;
                case EFAULT:
                    BTL_ERROR(("mca_btl_tipc_frag_send: writev error (%p, %lu)\n\t%s(%lu)\n",
                            frag->iov_ptr[0].iov_base, (unsigned long) frag->iov_ptr[0].iov_len,
                            strerror(opal_socket_errno), (unsigned long) frag->iov_cnt));
                    mca_btl_tipc_endpoint_close(frag->endpoint);
                    return false;
                default:
                    BTL_ERROR(("mca_btl_tipc_frag_send: writev failed: %s (%d)",
                            strerror(opal_socket_errno),
                            opal_socket_errno));
                    mca_btl_tipc_endpoint_close(frag->endpoint);
                    return false;
            }
        }
    }
    /* if the write didn't complete - update the iovec state */
    num_vecs = frag->iov_cnt;
    for (i = 0; i < num_vecs; i++) {
        if (cnt >= (int) frag->iov_ptr->iov_len) {
            cnt -= frag->iov_ptr->iov_len;
            frag->iov_ptr++;
            frag->iov_idx++;
            frag->iov_cnt--;
        } else {
            frag->iov_ptr->iov_base = (ompi_iov_base_ptr_t)
                    (((unsigned char*) frag->iov_ptr->iov_base) + cnt);
            frag->iov_ptr->iov_len -= cnt;
            break;
        }
    }
    return (frag->iov_cnt == 0);
}

bool mca_btl_tipc_frag_recv(mca_btl_tipc_frag_t* frag, int sd) {
/*
    DEBUG_INFO("mca_btl_tipc_frag_recv");
*/
#if ENABLE_DEBUG_INFO & 0
    /*-------------------------timing*/
    struct timespec start1, stop1;
    double accum1;
    if (clock_gettime(CLOCK_REALTIME, &start1) == -1) {
        perror("clock gettime");
    }
    /*-----------------------------*/
#endif
    int cnt, dont_copy_data = 0;
    size_t i, num_vecs;
    mca_btl_base_endpoint_t* btl_endpoint = frag->endpoint;

repeat:
    num_vecs = frag->iov_cnt;
    /* non-blocking read, but continue if interrupted */
    cnt = -1;
    while (cnt < 0) {
        cnt = readv(sd, frag->iov_ptr, num_vecs);
        if (0 < cnt) goto advance_iov_position;
        if (cnt == 0) {
            mca_btl_tipc_endpoint_close(btl_endpoint);
            return false;
        }
        switch (opal_socket_errno) {
            case EINTR:
                continue;
            case EWOULDBLOCK:
                return false;
            case EFAULT:
                BTL_ERROR(("mca_btl_tipc_frag_recv: readv error (%p, %lu)\n\t%s(%lu)\n",
                        frag->iov_ptr[0].iov_base, (unsigned long) frag->iov_ptr[0].iov_len,
                        strerror(opal_socket_errno), (unsigned long) frag->iov_cnt));
                mca_btl_tipc_endpoint_close(btl_endpoint);
                return false;
            default:
#if ENABLE_DEBUG_INFO
                BTL_ERROR(("mca_btl_tipc_frag_recv: readv failed: %s (%d)",
                        strerror(opal_socket_errno),
                        opal_socket_errno));
#endif
                mca_btl_tipc_endpoint_close(btl_endpoint);
                return false;
        }
    };

advance_iov_position:
    /* if the read didn't complete - update the iovec state */
    num_vecs = frag->iov_cnt;
    for (i = 0; i < num_vecs; i++) {
        if (cnt < (int) frag->iov_ptr->iov_len) {
            frag->iov_ptr->iov_base = (ompi_iov_base_ptr_t)
                    (((unsigned char*) frag->iov_ptr->iov_base) + cnt);
            frag->iov_ptr->iov_len -= cnt;
            cnt = 0;
            break;
        }
        cnt -= frag->iov_ptr->iov_len;
        frag->iov_idx++;
        frag->iov_ptr++;
        frag->iov_cnt--;
    }

    /* read header */
    if (frag->iov_cnt == 0) {
        switch (frag->hdr.type) {
            case MCA_BTL_TIPC_HDR_TYPE_SEND:
                if (frag->iov_idx == 1 && frag->hdr.size) {
                    frag->segments[0].seg_addr.pval = frag + 1;
                    frag->segments[0].seg_len = frag->hdr.size;
                    frag->iov[1].iov_base = (IOVBASE_TYPE*) (frag->segments[0].seg_addr.pval);
                    frag->iov[1].iov_len = frag->hdr.size;
                    frag->iov_cnt++;
                    goto repeat;
                }
                break;
            default:
                break;
        }
#if ENABLE_DEBUG_INFO & 0
        if (clock_gettime(CLOCK_REALTIME, &stop1) == -1) {
            perror("clock gettime");
        }

        accum1 = (stop1.tv_sec - start1.tv_sec) * 1000000
                + (double) (stop1.tv_nsec - start1.tv_nsec)
                / 1000;
        printf("%f\n", accum1);
#endif
        return true;
    }
    return false;
}