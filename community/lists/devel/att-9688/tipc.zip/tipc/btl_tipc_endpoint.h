/*
 * Copyright (c) 2011      Ericsson AB. All rights reserved.
 * Copyright (c) 2004-2007 The Trustees of Indiana University and Indiana
 *                         University Research and Technology
 *                         Corporation.  All rights reserved.
 * Copyright (c) 2004-2009 The University of Tennessee and The University
 *                         of Tennessee Research Foundation.  All rights
 *                         reserved.
 * Copyright (c) 2004-2005 High Performance Computing Center Stuttgart, 
 *                         University of Stuttgart.  All rights reserved.
 * Copyright (c) 2004-2005 The Regents of the University of California.
 *                         All rights reserved.
 * Copyright (c) 2010      Cisco Systems, Inc.  All rights reserved.
 * $COPYRIGHT$
 * 
 * Additional copyrights may follow
 * 
 * $HEADER$
 */

#ifndef MCA_BTL_TIPC_ENDPOINT_H
#define MCA_BTL_TIPC_ENDPOINT_H

#include "opal/class/opal_list.h"
#include "opal/mca/event/event.h"
#include "btl_tipc_frag.h"
#include <linux/tipc.h>

BEGIN_C_DECLS

/**
 * An abstraction that represents a connection to a endpoint process.
 * An instance of mca_btl_base_endpoint_t is associated w/ each process
 * and BTL pair at startup. However, connections to the endpoint
 * are established dynamically on an as-needed basis:
 */
typedef enum {
    MCA_BTL_TIPC_CONNECTING = 0,
    MCA_BTL_TIPC_CONNECT_SUCCESS,
    MCA_BTL_TIPC_CONNECT_ACK,
    MCA_BTL_TIPC_CLOSED,
    MCA_BTL_TIPC_FAILED,
    MCA_BTL_TIPC_CONNECTED
} mca_btl_tipc_state_t;

struct mca_btl_base_endpoint_t {
    opal_list_item_t super;

    struct mca_btl_tipc_module_t* endpoint_btl;
    /**< BTL instance that created this connection */

    struct mca_btl_tipc_proc_t* endpoint_proc;
    /**< proc structure corresponding to endpoint */

    mca_btl_tipc_state_t endpoint_state; /**< current state of the connection */
    struct mca_btl_tipc_frag_t* endpoint_send_frag; /**< current send frag being processed */
    int endpoint_sd;

    /*opal_list_t endpoint_frags;  */
    /**< list of pending frags to send */

    opal_mutex_t endpoint_send_lock; /**< lock for concurrent access to endpoint state */
    opal_mutex_t endpoint_recv_lock; /**< lock for concurrent access to endpoint state */
    opal_event_t endpoint_send_event; /**< event for async processing of send frags */
    opal_event_t endpoint_recv_event;
    opal_event_t endpoint_timeout_event; /*for connection*/
    struct sockaddr_tipc *endpoint_addr;
    struct mca_btl_tipc_frag_t* endpoint_recv_frag;
    /**< current recv frag being processed */

    opal_list_t endpoint_frags; /**< list of pending frags to send */
    pthread_t endpoint_pth_connection; 
    /* A thread for connection since TIPC does not support non-blocking connection for now. */

};

typedef struct mca_btl_base_endpoint_t mca_btl_base_endpoint_t;
typedef mca_btl_base_endpoint_t mca_btl_tipc_endpoint_t;
OBJ_CLASS_DECLARATION(mca_btl_tipc_endpoint_t);

/*
 * operation called by TIPC Module class when the upper layer wants to send data. 
 * However, the send may not 
 * complete here. Endpoint will check whether the peer process is connected. 
 * If yes, then send; otherwise, it will initiate a connection. After 
 * the establishment of connection, data will be send.
 */

int mca_btl_tipc_endpoint_send(mca_btl_base_endpoint_t* btl_endpoint, mca_btl_tipc_frag_t* frag);

/*a libevent callback function that used when data received.*/
static void mca_btl_tipc_endpoint_recv_handler(int sd, short flags, void* user);

void mca_btl_tipc_endpoint_close(mca_btl_base_endpoint_t* btl_endpoint);
/*
 * send process id to peer process. Two Processes need to exchange their process id before 
 * actually sending and receiving data.
 */
static int mca_btl_tipc_endpoint_send_process_id(mca_btl_base_endpoint_t* btl_endpoint);
static int mca_btl_tipc_endpoint_recv_process_id(mca_btl_base_endpoint_t* btl_endpoint);
static int mca_btl_tipc_endpoint_send_blocking(mca_btl_base_endpoint_t* btl_endpoint,
        void* data, size_t size);
void mca_btl_tipc_endpoint_event_init(mca_btl_base_endpoint_t* btl_endpoint);
void mca_btl_tipc_endpoint_event_init2(int socket, mca_btl_base_endpoint_t* btl_endpoint);
static void mca_btl_tipc_endpoint_send_handler(int sd, short flags, void* user);
bool mca_btl_tipc_endpoint_accept(mca_btl_base_endpoint_t*, struct sockaddr*, int);
void mca_btl_tipc_endpoint_connected(mca_btl_base_endpoint_t * btl_endpoint);
static int mca_btl_tipc_endpoint_recv_blocking(mca_btl_base_endpoint_t* btl_endpoint, void* data, size_t size);
static int mca_btl_tipc_endpoint_start_connect(mca_btl_base_endpoint_t* btl_endpoint);
void mca_btl_tipc_set_socket_options(int sd);
bool mca_btl_tipc_endpoint_service_exist(__u32 name_type, __u32 name_instance, int wait);
void *mca_btl_tipc_endpoint_thread_connect(void *arg);
void *mca_btl_tipc_endpoint_init_timer(mca_btl_base_endpoint_t* btl_endpoint);
END_C_DECLS
#endif

