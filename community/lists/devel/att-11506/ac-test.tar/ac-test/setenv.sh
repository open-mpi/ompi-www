export PATH=/opt/mpi/openmpi-1.5.3/bin/:$PATH
export LD_LIBRARY_PATH=/opt/mpi/openmpi-1.5.3/lib/:$LD_LIBRARY_PATH
