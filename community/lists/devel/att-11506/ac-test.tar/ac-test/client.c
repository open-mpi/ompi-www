#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main( int argc, char **argv ) {
	MPI_Init(&argc,&argv);

	int rank;
	int size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	char portname[MPI_MAX_PORT_NAME];
	
	strcpy(portname,"532086784.0;tcp://192.168.6.52:62316;tcp://134.61.98.22:62316+532086785.0;tcp://192.168.6.52:62317;tcp://134.61.98.22:62317:300");
	printf("portname is %s\n",portname);

	printf("rank: %d, worldsize:%d\n",rank, size);
	char port[MPI_MAX_PORT_NAME];
	MPI_Comm temp_comm, temp_comm2, acc_comm, acc_comm2 ;	
	
	MPI_Comm_connect(portname, MPI_INFO_NULL, 0, MPI_COMM_SELF, &temp_comm);
	MPI_Intercomm_merge(temp_comm, 0, &acc_comm);
	
	//acuire more accelerators
	strcpy(portname,"531955712.0;tcp://192.168.6.52:62319;tcp://134.61.98.22:62319+531955713.0;tcp://192.168.6.52:62320;tcp://134.61.98.22:62320:300");
	printf("portname is %s\n",portname);
	MPI_Send( portname, MPI_MAX_PORT_NAME, MPI_CHAR, 1, 99, acc_comm);
	MPI_Comm_connect(portname, MPI_INFO_NULL, 0, acc_comm, &temp_comm2);
	
	printf("miracle happened..\n"); fflush(stdout);
	MPI_Intercomm_merge(temp_comm2, 0, &acc_comm2);
	
	MPI_Finalize();
	return 0;
}
