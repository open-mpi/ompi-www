/*define interfaces for export*/
/* 
 * File:   btl_tipc.h
 * Author: Xin He (xin.i.he@ericsson.com)
 *
 * Created on June 21, 2011, 11:40 AM
 */
#ifndef MCA_BTL_TIPC_H
#define MCA_BTL_TIPC_H

#include "ompi_config.h"
#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif
#ifdef HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif
#ifdef HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif

/* Open MPI includes */
#include "opal/mca/event/event.h"
#include "ompi/class/ompi_free_list.h"
#include "ompi/mca/btl/btl.h"
#include "ompi/mca/btl/base/base.h"
#include "ompi/mca/mpool/mpool.h"
#include "ompi/mca/btl/btl.h"
#include "opal/class/opal_hash_table.h"
#include <linux/tipc.h>

BEGIN_C_DECLS

/**
 * BTL Module Interface
 */

struct mca_btl_tipc_module_t {
    mca_btl_base_module_t super; /**< base BTL interface */
    opal_list_t tipc_endpoints;
#if MCA_BTL_HAS_MPOOL
    struct mca_mpool_base_module_t* tipc_mpool;
#endif
};


typedef struct mca_btl_tipc_module_t mca_btl_tipc_module_t;
extern mca_btl_tipc_module_t mca_btl_tipc_module;

struct mca_btl_tipc_component_t {
    mca_btl_base_component_2_0_0_t super; /**< base BTL component */
    struct mca_btl_tipc_module_t **tipc_btls; /**< array of available BTL modules */
    struct mca_btl_tipc_proc_t* tipc_local; /**< local proc struct */
    uint32_t tipc_num_btls; /**< number of hcas available to the TIPC component */
    int tipc_listen_sd; /**< Listen socket for incoming connection requests */
    opal_event_t tipc_recv_event; /**< recv event for listen socket */
    unsigned short tipc_listen_port; /**< Listen port */

    int tipc_free_list_num;
    /**< initial size of free lists */

    int tipc_free_list_max;
    /**< maximum size of free lists */

    int tipc_free_list_inc;
    /**< number of elements to alloc when growing free lists */


    opal_hash_table_t tipc_procs; /**< hash table of tcp proc structures */
    /**< list of tipc proc structures */

    opal_mutex_t tipc_lock;
    /**< lock for accessing module state */

    char* tipc_mpool_name;
    /**< name of memory pool */

    bool leave_pinned;
    /**< pin memory on first use and leave pinned */
    opal_list_t tipc_events; /**< list of pending tcp events */

    int tipc_sndbuf; /**< socket sndbuf size */
    int tipc_rcvbuf; /**< socket rcvbuf size */

    ompi_free_list_t tipc_frag_eager;
    ompi_free_list_t tipc_frag_max;
    ompi_free_list_t tipc_frag_user;


};

typedef struct mca_btl_tipc_component_t mca_btl_tipc_component_t;

OMPI_MODULE_DECLSPEC extern mca_btl_tipc_component_t mca_btl_tipc_component;

extern int enable_debug_info; /*Print debug info or not*/

#define SERVER_INST  17
#define MAX_REC_SIZE 256

#define ENABLE_DEBUG_INFO 0
#if ENABLE_DEBUG_INFO
#define DEBUG_INFO(S) printf("Process: %d, Filename: %s, line: %d: %s\n",getpid(),__FILE__,__LINE__, S);
#else
#define DEBUG_INFO(S) ;
#endif

#define PRINT_INFO(S) printf("Process: %d, Filename: %s, line: %d: %s\n",getpid(),__FILE__,__LINE__, S);
/**
 * Register tipc component parameters with the MCA framework
 */
extern int mca_btl_tipc_component_open(void);

/**
 * Any final cleanup before being unloaded.
 */
extern int mca_btl_tipc_component_close(void);

/**
 * tipc component initialization.
 * 
 * @param num_btl_modules (OUT)           Number of BTLs returned in BTL array.
 * @param allow_multi_user_threads (OUT)  Flag indicating wether BTL supports user threads (TRUE)
 * @param have_hidden_threads (OUT)       Flag indicating wether BTL uses threads (TRUE)
 */
extern mca_btl_base_module_t** mca_btl_tipc_component_init(
        int *num_btl_modules, bool allow_multi_user_threads,
        bool have_hidden_threads);

/**
 * tipc component progress.
 */
extern int mca_btl_tipc_component_progress(void);

/**
 * Cleanup any resources held by the BTL.
 * 
 * @param btl  BTL instance.
 * @return     OMPI_SUCCESS or error status on failure.
 */

extern int mca_btl_tipc_finalize(struct mca_btl_base_module_t* btl);

/**
 * PML->BTL notification of change in the process list.
 * 
 * @param btl (IN)
 * @param nprocs (IN)     Number of processes
 * @param procs (IN)      Set of processes
 * @param peers (OUT)     Set of (optional) peer addressing info.
 * @param peers (IN/OUT)  Set of processes that are reachable via this BTL.
 * @return     OMPI_SUCCESS or error status on failure.
 * 
 */

extern int mca_btl_tipc_add_procs(struct mca_btl_base_module_t* btl,
        size_t nprocs, struct ompi_proc_t **procs,
        struct mca_btl_base_endpoint_t** peers, opal_bitmap_t* reachable);

/**
 * PML->BTL notification of change in the process list.
 *
 * @param btl (IN)     BTL instance
 * @param nproc (IN)   Number of processes.
 * @param procs (IN)   Set of processes.
 * @param peers (IN)   Set of peer data structures.
 * @return             Status indicating if cleanup was successful
 *
 */

extern int mca_btl_tipc_del_procs(struct mca_btl_base_module_t* btl,
        size_t nprocs, struct ompi_proc_t **procs,
        struct mca_btl_base_endpoint_t** peers);

/**
 * Initiate an asynchronous send.
 *
 * @param btl (IN)         BTL module
 * @param endpoint (IN)    BTL addressing information
 * @param descriptor (IN)  Description of the data to be transfered
 * @param tag (IN)         The tag value used to notify the peer.
 */

extern int mca_btl_tipc_send(struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* btl_peer,
        struct mca_btl_base_descriptor_t* descriptor, mca_btl_base_tag_t tag);

/**
 * Initiate an asynchronous put.
 *
 * @param btl (IN)         BTL module
 * @param endpoint (IN)    BTL addressing information
 * @param descriptor (IN)  Description of the data to be transferred
 */

extern int mca_btl_tipc_put(struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* btl_peer,
        struct mca_btl_base_descriptor_t* decriptor);

/**
 * Initiate an asynchronous get.
 *
 * @param btl (IN)         BTL module
 * @param endpoint (IN)    BTL addressing information
 * @param descriptor (IN)  Description of the data to be transferred
 */

extern int mca_btl_tipc_get(struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* btl_peer,
        struct mca_btl_base_descriptor_t* decriptor);

/**
 * Register a callback function that is called on receipt
 * of a fragment.
 *
 * @param btl (IN)     BTL module
 * @return             Status indicating if registration was successful
 *
 */

extern int mca_btl_tipc_register(struct mca_btl_base_module_t* btl,
        mca_btl_base_tag_t tag, mca_btl_base_module_recv_cb_fn_t cbfunc,
        void* cbdata);

/**
 * Allocate a descriptor with a segment of the requested size.
 * Note that the BTL layer may choose to return a smaller size
 * if it cannot support the request.
 *
 * @param btl (IN)      BTL module
 * @param size (IN)     Request segment size.
 */

extern mca_btl_base_descriptor_t* mca_btl_tipc_alloc(
        struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* endpoint, uint8_t order, size_t size,
        uint32_t flags);

/**
 * Return a segment allocated by this BTL.
 *
 * @param btl (IN)      BTL module
 * @param descriptor (IN)  Allocated descriptor.
 */

extern int mca_btl_tipc_free(struct mca_btl_base_module_t* btl,
        mca_btl_base_descriptor_t* des);

/**
 * Prepare a descriptor for send/rdma using the supplied
 * convertor. If the convertor references data that is contigous,
 * the descriptor may simply point to the user buffer. Otherwise,
 * this routine is responsible for allocating buffer space and
 * packing if required.
 *
 * @param btl (IN)          BTL module
 * @param endpoint (IN)     BTL peer addressing
 * @param convertor (IN)    Data type convertor
 * @param reserve (IN)      Additional bytes requested by upper layer to precede user data
 * @param size (IN/OUT)     Number of bytes to prepare (IN), number of bytes actually prepared (OUT) 
 */

mca_btl_base_descriptor_t* mca_btl_tipc_prepare_src(
        struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* peer,
        struct mca_mpool_base_registration_t* registration,
        struct opal_convertor_t* convertor,
        uint8_t order,
        size_t reserve,
        size_t* size,
        uint32_t flags
        );

extern mca_btl_base_descriptor_t* mca_btl_tipc_prepare_dst(
        struct mca_btl_base_module_t* btl,
        struct mca_btl_base_endpoint_t* peer,
        struct mca_mpool_base_registration_t*,
        struct opal_convertor_t* convertor,
        uint8_t order,
        size_t reserve,
        size_t* size,
        uint32_t flags);

/**
 * Fault Tolerance Event Notification Function
 * @param state Checkpoint Stae
 * @return OMPI_SUCCESS or failure status
 */
int mca_btl_tipc_ft_event(int state);




END_C_DECLS
#endif