#include "ompi_config.h"

#ifdef HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif
#ifdef HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif

#include "opal/class/opal_hash_table.h"
#include "ompi/mca/btl/base/btl_base_error.h"
#include "ompi/runtime/ompi_module_exchange.h"
#include "opal/util/arch.h"
#include "opal/util/argv.h"
#include "opal/util/if.h"
#include "opal/util/net.h"

#include "btl_tipc.h"
#include "btl_tipc_proc.h"

/*
 * Create a tipc process structure. There is a one-to-one correspondence
 * between a ompi_proc_t and a mca_btl_tipc_proc_t instance. We cache
 * additional data (specifically the list of mca_btl_tipc_endpoint_t instances, 
 * and published addresses) associated w/ a given destination on this
 * datastructure.
 */
static void mca_btl_tipc_proc_construct(mca_btl_tipc_proc_t* proc);
static void mca_btl_tipc_proc_destruct(mca_btl_tipc_proc_t* proc);


OBJ_CLASS_INSTANCE(mca_btl_tipc_proc_t,
        opal_list_item_t, mca_btl_tipc_proc_construct,
        mca_btl_tipc_proc_destruct);

void mca_btl_tipc_proc_construct(mca_btl_tipc_proc_t* tipc_proc) {
    tipc_proc->proc_ompi = 0;
    tipc_proc->proc_addrs = NULL;
    tipc_proc->proc_addr_count = 0;
    tipc_proc->proc_endpoints = NULL;
    tipc_proc->proc_endpoint_count = 0;
    OBJ_CONSTRUCT(&tipc_proc->proc_lock, opal_mutex_t);

    /*
         add to list of all proc instance 
        OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
        opal_list_append(&mca_btl_tipc_component.tipc_procs, &tipc_proc->super);
        OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);
     */
}

/*
 * Cleanup ib proc instance
 */

void mca_btl_tipc_proc_destruct(mca_btl_tipc_proc_t* tipc_proc) {
    /* remove from list of all proc instances */
    OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
    opal_hash_table_remove_value_uint64(&mca_btl_tipc_component.tipc_procs,
            orte_util_hash_name(&tipc_proc->proc_ompi->proc_name));

    /*
        opal_list_remove_item(&mca_btl_tipc_component.tipc_procs,
                &tipc_proc->super);
     */
    OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);

    /* release resources */
    if (NULL != tipc_proc->proc_endpoints) {
        free(tipc_proc->proc_endpoints);
    }
    OBJ_DESTRUCT(&tipc_proc->proc_lock);
}

static mca_btl_tipc_proc_t* mca_btl_tipc_proc_lookup_ompi(ompi_proc_t* ompi_proc) {
    return NULL;
}

mca_btl_tipc_proc_t* mca_btl_tipc_proc_create(ompi_proc_t* ompi_proc) {
    int rc;
    size_t size;
    mca_btl_tipc_proc_t* btl_proc;
    uint64_t hash = orte_util_hash_name(&ompi_proc->proc_name);

    OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
    rc = opal_hash_table_get_value_uint64(&mca_btl_tipc_component.tipc_procs,
            hash, (void**) &btl_proc);
    if (OMPI_SUCCESS == rc) {
        OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);
        return btl_proc;
    }


    btl_proc = OBJ_NEW(mca_btl_tipc_proc_t);

    if (NULL == btl_proc)
        return NULL;
    btl_proc->proc_ompi = ompi_proc;

    /* add to hash table of all proc instance */
    opal_hash_table_set_value_uint64(&mca_btl_tipc_component.tipc_procs,
            hash, btl_proc);
    OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);

    /* lookup tipc parameters exported by this proc */
    rc = ompi_modex_recv(&mca_btl_tipc_component.super.btl_version,
            ompi_proc,
            (void**) &btl_proc->proc_addrs,
            &size);

    if (rc != OMPI_SUCCESS) {
        BTL_ERROR(("mca_base_modex_recv: failed with return value=%d", rc));
        OBJ_RELEASE(btl_proc);
        return NULL;
    }
    /*
        if (btl_proc->proc_addrs != NULL)
            printf("btl_proc->proc_addrs->addr.nameseq.type = %d\n", btl_proc->proc_addrs->addr.nameseq.type);
     */

    btl_proc->proc_addr_count = 1;

    /* allocate space for endpoint array - one for each exported address */
    btl_proc->proc_endpoints = (mca_btl_base_endpoint_t**)
            malloc((1 + btl_proc->proc_addr_count) *
            sizeof (mca_btl_base_endpoint_t*));

    if (NULL == btl_proc->proc_endpoints) {
        OBJ_RELEASE(btl_proc);
        return NULL;
    }
    if (NULL == mca_btl_tipc_component.tipc_local && ompi_proc == ompi_proc_local()) {
        mca_btl_tipc_component.tipc_local = btl_proc;
    }
    return btl_proc;
}

int mca_btl_tipc_proc_insert(mca_btl_tipc_proc_t* module_proc,
        mca_btl_base_endpoint_t* module_endpoint) {
    /* insert into endpoint array */
    module_endpoint->endpoint_proc = module_proc;
    module_proc->proc_endpoints[module_proc->proc_endpoint_count++] = module_endpoint;
    /*Unlike tcp, tipc only have 1 address, so there is no need to find the "best" address*/
    module_endpoint->endpoint_addr = module_proc->proc_addrs;
    return OMPI_SUCCESS;
}

/*
 * Look for an existing tipc process instance based on the globally unique
 * process identifier.
 */
mca_btl_tipc_proc_t* mca_btl_tipc_proc_lookup(const orte_process_name_t *name) {
    mca_btl_tipc_proc_t* proc = NULL;
    OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
    opal_hash_table_get_value_uint64(&mca_btl_tipc_component.tipc_procs,
            orte_util_hash_name(name), (void**) &proc);
    /*
        uint64_t *key;
        int *node;
        opal_hash_table_get_first_key_uint64(&mca_btl_tipc_component.tipc_procs,
                key,(void**)&proc,(void **)&node);
     */
    OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);
    return proc;
}

bool mca_btl_tipc_proc_accept(mca_btl_tipc_proc_t* btl_proc, struct sockaddr* addr, int sd) {
    OPAL_THREAD_LOCK(&btl_proc->proc_lock);
    mca_btl_base_endpoint_t* btl_endpoint = btl_proc->proc_endpoints[0];
    if (mca_btl_tipc_endpoint_accept(btl_endpoint, addr, sd)) {
        OPAL_THREAD_UNLOCK(&btl_proc->proc_lock);
        return true;
    }
    OPAL_THREAD_UNLOCK(&btl_proc->proc_lock);
    return false;
}

/*
 * Remove an endpoint from the proc array and indicate the address is
 * no longer in use.
 */

int mca_btl_tipc_proc_remove(mca_btl_tipc_proc_t* btl_proc, mca_btl_base_endpoint_t* btl_endpoint) {
    size_t i;
    OPAL_THREAD_LOCK(&btl_proc->proc_lock);
    for (i = 0; i < btl_proc->proc_endpoint_count; i++) {
        if (btl_proc->proc_endpoints[i] == btl_endpoint) {
            memmove(btl_proc->proc_endpoints + i, btl_proc->proc_endpoints + i + 1,
                    (btl_proc->proc_endpoint_count - i - 1) * sizeof (mca_btl_base_endpoint_t*));
            if (--btl_proc->proc_endpoint_count == 0) {
                OPAL_THREAD_UNLOCK(&btl_proc->proc_lock);
                OBJ_RELEASE(btl_proc);
                return OMPI_SUCCESS;
            }
            break;
        }
    }
    OPAL_THREAD_UNLOCK(&btl_proc->proc_lock);
    return OMPI_SUCCESS;
}