#include "ompi_config.h"

#include <stdlib.h>
#include <string.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include "opal/opal_socket_errno.h"
#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif
#ifdef HAVE_FCNTL_H
#include <fcntl.h>
#endif
#ifdef HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif

#ifdef HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#endif  /* HAVE_SYS_TIME_H */
#ifdef HAVE_TIME_H
#include <time.h>
#endif  /* HAVE_TIME_H */

#include <linux/tipc.h>
#include "opal/mca/event/event.h"

#include "ompi/types.h"
#include "ompi/mca/btl/base/btl_base_error.h"
#include "opal/util/net.h"

#include "btl_tipc.h"
#include "btl_tipc_endpoint.h" 
#include "btl_tipc_proc.h"
#include "btl_tipc_frag.h"

/*
#include "btl_tipc_addr.h"
 * 
 * 
 */
static void mca_btl_tipc_endpoint_construct(mca_btl_tipc_endpoint_t* endpoint) {
    endpoint->endpoint_btl = NULL;
    endpoint->endpoint_proc = NULL;
    endpoint->endpoint_addr = NULL;
    endpoint->endpoint_sd = -1;
    endpoint->endpoint_send_frag = 0;
    endpoint->endpoint_recv_frag = 0;
    endpoint->endpoint_state = MCA_BTL_TIPC_CLOSED;
    OBJ_CONSTRUCT(&endpoint->endpoint_send_lock, opal_mutex_t);
    OBJ_CONSTRUCT(&endpoint->endpoint_recv_lock, opal_mutex_t);
    OBJ_CONSTRUCT(&endpoint->endpoint_frags, opal_list_t);
}

/*
 * Destroy a endpoint
 *
 */

static void mca_btl_tipc_endpoint_destruct(mca_btl_base_endpoint_t* endpoint) {
    if (endpoint->endpoint_pth_connection) {
        pthread_join(endpoint->endpoint_pth_connection, NULL);
        endpoint->endpoint_pth_connection = 0;
    }
    mca_btl_tipc_proc_remove(endpoint->endpoint_proc, endpoint);
    mca_btl_tipc_endpoint_close(endpoint);
    OBJ_DESTRUCT(&endpoint->endpoint_frags);
    OBJ_DESTRUCT(&endpoint->endpoint_send_lock);
    OBJ_DESTRUCT(&endpoint->endpoint_recv_lock);
}


OBJ_CLASS_INSTANCE(
        mca_btl_tipc_endpoint_t,
        opal_list_item_t,
        mca_btl_tipc_endpoint_construct,
        mca_btl_tipc_endpoint_destruct);

bool mca_btl_tipc_endpoint_is_connected(int FD) {
    int optval;
    socklen_t optlen = sizeof (optval);
    int res = getsockopt(FD, SOL_SOCKET, SO_ERROR, &optval, &optlen);
    if (optval == 0 && res == 0) return true;
    return false;
}

void mca_btl_tipc_endpoint_event_init(mca_btl_base_endpoint_t* btl_endpoint) {
    opal_event_set(opal_event_base, &btl_endpoint->endpoint_recv_event,
            btl_endpoint->endpoint_sd,
            OPAL_EV_READ | OPAL_EV_PERSIST,
            mca_btl_tipc_endpoint_recv_handler,
            btl_endpoint);
    /**
     * The send event should be non persistent until the endpoint is
     * completely connected. This means, when the event is created it
     * will be fired only once, and when the endpoint is marked as 
     * CONNECTED the event should be recreated with the correct flags.
     */
    opal_event_set(opal_event_base, &btl_endpoint->endpoint_send_event,
            btl_endpoint->endpoint_sd,
            OPAL_EV_WRITE,
            mca_btl_tipc_endpoint_send_handler,
            btl_endpoint);
}

/*
 * Check the status of the connection. If the connection failed, will retry
 * later. Otherwise, send this processes identifier to the endpoint on the 
 * newly connected socket.
 */

void mca_btl_tipc_endpoint_complete_connect(mca_btl_base_endpoint_t *btl_endpoint) {
    struct timeval tv;
    if (btl_endpoint->endpoint_state == MCA_BTL_TIPC_CONNECTING) {
        tv.tv_sec = 0;
        tv.tv_usec = 1000;
        opal_event_add(&btl_endpoint->endpoint_timeout_event, &tv);
    } else {
        DEBUG_INFO("mca_btl_tipc_endpoint_complete_connect");
        if (btl_endpoint->endpoint_pth_connection) {
            pthread_join(btl_endpoint->endpoint_pth_connection, NULL);
            btl_endpoint->endpoint_pth_connection = 0;
        }
        int so_error = -1;
        opal_socklen_t so_length = sizeof (so_error);
        /* unregister from receiving event notifications */
        opal_event_del(&btl_endpoint->endpoint_timeout_event);

        int rc;
        /* send our globally unique process identifier to the endpoint */
        if ((rc = mca_btl_tipc_endpoint_send_process_id(btl_endpoint)) == OMPI_SUCCESS) {
            btl_endpoint->endpoint_state = MCA_BTL_TIPC_CONNECT_ACK;
            opal_event_add(&btl_endpoint->endpoint_recv_event, 0);
        } else {
            mca_btl_tipc_endpoint_close(btl_endpoint);
        }
        return rc;
    }
}

void mca_btl_tipc_set_socket_options(int sd) {

    /*
    #if defined(SO_SNDBUF)
        if (mca_btl_tipc_component.tipc_sndbuf > 0 &&
                setsockopt(sd, SOL_SOCKET, SO_SNDBUF, (char *) &mca_btl_tipc_component.tipc_sndbuf, sizeof (int)) < 0) {
            BTL_ERROR(("setsockopt(SO_SNDBUF) failed: %s (%d)",
                    strerror(opal_socket_errno), opal_socket_errno));
        }
    #endif
    #if defined(SO_RCVBUF)
        if (mca_btl_tipc_component.tipc_rcvbuf > 0 &&
                setsockopt(sd, SOL_SOCKET, SO_RCVBUF, (char *) &mca_btl_tipc_component.tipc_rcvbuf, sizeof (int)) < 0) {
            BTL_ERROR(("setsockopt(SO_RCVBUF) failed: %s (%d)",
                    strerror(opal_socket_errno), opal_socket_errno));
        }
    #endif
     */

}

/*
    DEBUG_INFO("mca_btl_tipc_endpoint_start_connect"); *  Start a connection to the endpoint. This will likely not complete,
 *  as the socket is set to non-blocking, so register for event
 *  notification of connect completion. On connection we send
 *  our globally unique process identifier to the endpoint and wait for
 *  the endpoints response.
 */
static int mca_btl_tipc_endpoint_start_connect(mca_btl_base_endpoint_t* btl_endpoint) {
    struct timeval tv;
    DEBUG_INFO("mca_btl_tipc_endpoint_start_connect");
    OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
    btl_endpoint->endpoint_sd = socket(AF_TIPC, SOCK_STREAM, 0);
    OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);
    if (btl_endpoint->endpoint_sd < 0) {
        DEBUG_INFO("Create socket failed");
        return OMPI_ERR_UNREACH;
    } else {
        /*
                DEBUG_INFO("socket info");
                printf("%d\n", btl_endpoint->endpoint_sd);
         */
    }
    /*register with libevent so we will get callback when connected*/
    /* setup event callbacks */
    btl_endpoint->endpoint_state = MCA_BTL_TIPC_CONNECTING;
    mca_btl_tipc_endpoint_init_timer(btl_endpoint);

    /*connect in another thread, since TIPC does not support nonblocking conn for now*/
    pthread_create(&btl_endpoint->endpoint_pth_connection, NULL, mca_btl_tipc_endpoint_thread_connect, (void *) btl_endpoint);

    tv.tv_sec = 0;
    tv.tv_usec = 1000;
    opal_event_add(&btl_endpoint->endpoint_timeout_event, &tv);
    return OMPI_SUCCESS;
}

void *mca_btl_tipc_endpoint_thread_connect(void *arg) {
    mca_btl_base_endpoint_t* btl_endpoint = (mca_btl_base_endpoint_t *) arg;
    DEBUG_INFO("mca_btl_tipc_endpoint_threadConnect");
#if ENABLE_DEBUG_INFO
    printf("socket = %d\n", btl_endpoint->endpoint_sd);
#endif
    struct sockaddr_tipc server_addr;
    struct sockaddr_tipc *to_addr = btl_endpoint->endpoint_addr;

    server_addr.family = AF_TIPC;
    server_addr.addrtype = TIPC_ADDR_NAME;
    server_addr.addr.name.name.type = to_addr->addr.nameseq.type;
    server_addr.addr.name.name.instance = to_addr->addr.nameseq.lower;
    server_addr.addr.name.domain = 0;

#if ENABLE_DEBUG_INFO & 0
    DEBUG_INFO("server_info");
    printf("type: %d, instance: %d\n", to_addr->addr.nameseq.type, server_addr.addr.name.name.instance);
#endif

    mca_btl_tipc_endpoint_service_exist(server_addr.addr.name.name.type, server_addr.addr.name.name.instance, 1000);

    if (connect(btl_endpoint->endpoint_sd,
            (struct sockaddr *) &server_addr,
            sizeof (server_addr)) != 0) {
        /*
         * One reason why connection failed and print out "Resource temporarily unavailbale is 
         * because the value of endpoint socket got changed by accept. We can ignore this error
         * and discard the connection.
         */
        DEBUG_INFO("conn failed");
        perror("Client: connect failed");
    } else {
        DEBUG_INFO("connected to peer\n");
        if (btl_endpoint->endpoint_state == MCA_BTL_TIPC_CONNECTING) {
            /* 
             * During the connection, the endpoint socket might be changed by the other thread!
             * In another way of speaking, another connection is established!
             * In that case, we can just discard this connection
             */
            btl_endpoint->endpoint_state = MCA_BTL_TIPC_CONNECT_SUCCESS;
#if ENABLE_DEBUG_INFO
            printf("socket = %d\n", btl_endpoint->endpoint_sd);
#endif
            mca_btl_tipc_endpoint_event_init(btl_endpoint);
        }
    }
}

int mca_btl_tipc_endpoint_send(mca_btl_base_endpoint_t* btl_endpoint, mca_btl_tipc_frag_t* frag) {
    int rc = OMPI_SUCCESS;
    OPAL_THREAD_LOCK(&btl_endpoint->endpoint_send_lock);
    switch (btl_endpoint->endpoint_state) {
            /*use connection communication for this "connection" version*/
        case MCA_BTL_TIPC_CONNECTING:
        case MCA_BTL_TIPC_CONNECT_ACK:
        case MCA_BTL_TIPC_CLOSED:
            /*
                        btl_endpoint->endpoint_send_frag = frag;
             */
            opal_list_append(&btl_endpoint->endpoint_frags, (opal_list_item_t*) frag);
            frag->base.des_flags |= MCA_BTL_DES_SEND_ALWAYS_CALLBACK;
            if (btl_endpoint->endpoint_state == MCA_BTL_TIPC_CLOSED)
                rc = mca_btl_tipc_endpoint_start_connect(btl_endpoint);
            break;
        case MCA_BTL_TIPC_FAILED:
            rc = OMPI_ERR_UNREACH;
            break;
        case MCA_BTL_TIPC_CONNECTED:
            if (btl_endpoint->endpoint_send_frag == NULL) {
                /*
                                DEBUG_INFO("mca_btl_tipc_frag_send");
                 */
                if (frag->base.des_flags & MCA_BTL_DES_FLAGS_PRIORITY &&
                        mca_btl_tipc_frag_send(frag, btl_endpoint->endpoint_sd)) {
                    int btl_ownership = (frag->base.des_flags & MCA_BTL_DES_FLAGS_BTL_OWNERSHIP);

                    OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
                    if (frag->base.des_flags & MCA_BTL_DES_SEND_ALWAYS_CALLBACK) {
                        frag->base.des_cbfunc(&frag->btl->super, frag->endpoint, &frag->base, frag->rc);
                    }
                    if (btl_ownership) {
                        /*
                                                PRINT_INFO("btl_ownership");
                         */
                        MCA_BTL_TIPC_FRAG_RETURN(frag);
                    }
                    return 1;
                } else {
                    btl_endpoint->endpoint_send_frag = frag;
                    opal_event_add(&btl_endpoint->endpoint_send_event, 0);
                    frag->base.des_flags |= MCA_BTL_DES_SEND_ALWAYS_CALLBACK;
                }
            } else {
                frag->base.des_flags |= MCA_BTL_DES_SEND_ALWAYS_CALLBACK;
                opal_list_append(&btl_endpoint->endpoint_frags, (opal_list_item_t*) frag);
            }
            break;
#if 0        
            /*send the data*/
            mca_btl_tipc_frag_send(frag, btl_endpoint->endpoint_sd);
            OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
            frag->base.des_flags |= MCA_BTL_DES_SEND_ALWAYS_CALLBACK;
            if (frag->base.des_flags & MCA_BTL_DES_SEND_ALWAYS_CALLBACK) {
                DEBUG_INFO("call back send function");
                frag->base.des_cbfunc(&frag->btl->super, frag->endpoint, &frag->base, frag->rc);
            }
            break;
#endif
    }

    OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
    return rc;
}

static void mca_btl_tipc_endpoint_recv_handler(int sd, short flags, void* user) {
    /*
        DEBUG_INFO("mca_btl_tipc_endpoint_recv_handler");
     */
    mca_btl_base_endpoint_t* btl_endpoint = (mca_btl_base_endpoint_t *) user;

    /* Make sure we don't have a race between a thread that remove the
     * recv event, and one event already scheduled.
     */
    if (sd != btl_endpoint->endpoint_sd)
        return;

    OPAL_THREAD_LOCK(&btl_endpoint->endpoint_recv_lock);
    switch (btl_endpoint->endpoint_state) {
        case MCA_BTL_TIPC_CONNECT_ACK:
        {
            /*sent process id to peer, get the response*/
            int rc = OMPI_ERROR;
            rc = mca_btl_tipc_endpoint_recv_process_id(btl_endpoint);
            if (OMPI_SUCCESS == rc) {
                /* we are now connected. Start sending the data */
                OPAL_THREAD_LOCK(&btl_endpoint->endpoint_send_lock);
                mca_btl_tipc_endpoint_connected(btl_endpoint);
                OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
            }
            OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_recv_lock);
            return;
            break;
        }
        case MCA_BTL_TIPC_CONNECTED:
        {
            mca_btl_tipc_frag_t* frag = NULL;

            frag = btl_endpoint->endpoint_recv_frag;
            if (NULL == frag) {
                int rc;
                if (mca_btl_tipc_module.super.btl_max_send_size >
                        mca_btl_tipc_module.super.btl_eager_limit) {
                    MCA_BTL_TIPC_FRAG_ALLOC_MAX(frag, rc);
                } else {
                    MCA_BTL_TIPC_FRAG_ALLOC_EAGER(frag, rc);
                }

                if (NULL == frag) {
                    OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_recv_lock);
                    return;
                }
                MCA_BTL_TIPC_FRAG_INIT_DST(frag, btl_endpoint);
            }
            if (mca_btl_tipc_frag_recv(frag, btl_endpoint->endpoint_sd) == false) {
                btl_endpoint->endpoint_recv_frag = frag;
            } else {
                btl_endpoint->endpoint_recv_frag = NULL;
                if (MCA_BTL_TIPC_HDR_TYPE_SEND == frag->hdr.type) {
                    mca_btl_active_message_callback_t* reg;
                    reg = mca_btl_base_active_message_trigger + frag->hdr.base.tag;
                    reg->cbfunc(&frag->btl->super, frag->hdr.base.tag, &frag->base, reg->cbdata);
                    MCA_BTL_TIPC_FRAG_RETURN(frag);
                }
            }
            OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_recv_lock);
            break;
        }
    }
}

/*
 * Send the globally unique identifier for this process to a endpoint on 
 * a newly connected socket.
 */

static int mca_btl_tipc_endpoint_send_process_id(mca_btl_base_endpoint_t* btl_endpoint) {
    /* send process identifier to remote endpoint */
    mca_btl_tipc_proc_t* btl_proc = mca_btl_tipc_proc_local();
    orte_process_name_t guid = btl_proc->proc_ompi->proc_name;

    ORTE_PROCESS_NAME_HTON(guid);
    if (mca_btl_tipc_endpoint_send_blocking(btl_endpoint, &guid, sizeof (guid)) !=
            sizeof (guid)) {

        return OMPI_ERR_UNREACH;
    }
    DEBUG_INFO("sent process id");
#if ENABLE_DEBUG_INFO
    printf("process id: %d\n", guid.jobid);
#endif
    return OMPI_SUCCESS;

}

/*
 * A blocking send on a non-blocking socket. Used to send the small amount of connection
 * information that identifies the endpoints endpoint.
 */
static int mca_btl_tipc_endpoint_send_blocking(mca_btl_base_endpoint_t* btl_endpoint,
        void* data, size_t size) {
    DEBUG_INFO("mca_btl_tipc_endpoint_send_blocking");
#if ENABLE_DEBUG_INFO
    printf("socket = %d\n", btl_endpoint->endpoint_sd);
#endif
    unsigned char* ptr = (unsigned char*) data;
    size_t cnt = 0;
    while (cnt < size) {
        int retval = send(btl_endpoint->endpoint_sd,
                (const char *) ptr + cnt,
                size - cnt,
                0);
        if (retval < 0) {
            if (opal_socket_errno != EINTR && opal_socket_errno != EAGAIN && opal_socket_errno != EWOULDBLOCK) {
                BTL_ERROR(("send() failed: %s (%d)\n",
                        strerror(opal_socket_errno), opal_socket_errno));
                mca_btl_tipc_endpoint_close(btl_endpoint);
                return -1;
            }
            continue;
        }
        cnt += retval;
    }
    return cnt;
}

/*
 * Remove any event registrations associated with the socket
 * and update the endpoint state to reflect the connection has
 * been closed.
 */
void mca_btl_tipc_endpoint_close(mca_btl_base_endpoint_t * btl_endpoint) {
    if (btl_endpoint->endpoint_sd < 0) {
        return;
    }
    btl_endpoint->endpoint_state = MCA_BTL_TIPC_CLOSED;
    opal_event_del(&btl_endpoint->endpoint_recv_event);
    opal_event_del(&btl_endpoint->endpoint_send_event);
    close(btl_endpoint->endpoint_sd);
    btl_endpoint->endpoint_sd = -1;
}

/*
 * A file descriptor is available/ready for send. Check the state
 * of the socket and take the appropriate action.
 */

static void mca_btl_tipc_endpoint_send_handler(int sd, short flags, void* user) {
    mca_btl_tipc_endpoint_t* btl_endpoint = (mca_btl_tipc_endpoint_t *) user;
    OPAL_THREAD_LOCK(&btl_endpoint->endpoint_send_lock);
    switch (btl_endpoint->endpoint_state) {
        case MCA_BTL_TIPC_CONNECTING:
        case MCA_BTL_TIPC_CONNECT_SUCCESS:
            /*send the process id to peer*/
            mca_btl_tipc_endpoint_complete_connect(btl_endpoint);
            break;
        case MCA_BTL_TIPC_CONNECTED:
            /*send out the data*/
            while (NULL != btl_endpoint->endpoint_send_frag) {
                mca_btl_tipc_frag_t* frag = btl_endpoint->endpoint_send_frag;
                int btl_ownership = (frag->base.des_flags & MCA_BTL_DES_FLAGS_BTL_OWNERSHIP);
                if (mca_btl_tipc_frag_send(frag, btl_endpoint->endpoint_sd) == false) {
                    break;
                }
                /* progress anymca_btl_tipc_endpoint_service_exist pending sends */
                btl_endpoint->endpoint_send_frag = (mca_btl_tipc_frag_t*)
                        opal_list_remove_first(&btl_endpoint->endpoint_frags);

                /* if required - update request status and release fragment */
                OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);

                assert(frag->base.des_flags & MCA_BTL_DES_SEND_ALWAYS_CALLBACK);
                frag->base.des_cbfunc(&frag->btl->super, frag->endpoint, &frag->base, frag->rc);
                if (btl_ownership) {
                    MCA_BTL_TIPC_FRAG_RETURN(frag);
                }
                OPAL_THREAD_LOCK(&btl_endpoint->endpoint_send_lock);
            }
            if (NULL == btl_endpoint->endpoint_send_frag) {
                opal_event_del(&btl_endpoint->endpoint_send_event);
            }
            break;
        default:
            BTL_ERROR(("invalid connection state (%d)", btl_endpoint->endpoint_state));
            opal_event_del(&btl_endpoint->endpoint_send_event);
            break;
    }
    OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
}

/*
 * Check the state of this endpoint. If the incoming connection request matches
 * our endpoints address, check the state of our connection:
 * (1) if a connection has not been attempted, accept the connection
 * (2) if a connection has not been established, and the endpoints process identifier
 *     is less than the local process, accept the connection
 * otherwise, reject the connection and continue with the current connection 
 */

bool mca_btl_tipc_endpoint_accept(mca_btl_base_endpoint_t* btl_endpoint,
        struct sockaddr* addr, int sd) {



    mca_btl_tipc_proc_t* this_proc = mca_btl_tipc_proc_local();
    mca_btl_tipc_proc_t *endpoint_proc = btl_endpoint->endpoint_proc;
    int cmpval;

    OPAL_THREAD_LOCK(&btl_endpoint->endpoint_recv_lock);
    OPAL_THREAD_LOCK(&btl_endpoint->endpoint_send_lock);

    if (NULL == btl_endpoint->endpoint_addr) {
        OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
        OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_recv_lock);
        return false;
    }

    cmpval = orte_util_compare_name_fields(ORTE_NS_CMP_ALL,
            &endpoint_proc->proc_ompi->proc_name,
            &this_proc->proc_ompi->proc_name);
    if ((btl_endpoint->endpoint_sd < 0) ||
            (btl_endpoint->endpoint_state != MCA_BTL_TIPC_CONNECTED &&
            cmpval < 0)) {
        mca_btl_tipc_endpoint_close(btl_endpoint);
        btl_endpoint->endpoint_sd = sd;
        if (mca_btl_tipc_endpoint_send_process_id(btl_endpoint) != OMPI_SUCCESS) {
            mca_btl_tipc_endpoint_close(btl_endpoint);
            OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
            OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_recv_lock);
            return false;
        }
        mca_btl_tipc_endpoint_event_init(btl_endpoint);
        opal_event_add(&btl_endpoint->endpoint_recv_event, 0);
        mca_btl_tipc_endpoint_connected(btl_endpoint);

        OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
        OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_recv_lock);
        return true;
    }
    OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_send_lock);
    OPAL_THREAD_UNLOCK(&btl_endpoint->endpoint_recv_lock);
    return false;
}

void mca_btl_tipc_endpoint_connected(mca_btl_base_endpoint_t * btl_endpoint) {
    /* setup socket options */
    btl_endpoint->endpoint_state = MCA_BTL_TIPC_CONNECTED;
    /*


        if (!is_connected(btl_endpoint->endpoint_sd)) {
            DEBUG_INFO("NOT connected%d");
        }
     */

    DEBUG_INFO("mca_btl_tipc_endpoint_connected");
#if ENABLE_DEBUG_INFO
    printf("socket = %d\n", btl_endpoint->endpoint_sd);
#endif

    int flags;
    /* setup the socket as non-blocking */
    if ((flags = fcntl(btl_endpoint->endpoint_sd, F_GETFL, 0)) < 0) {
        BTL_ERROR(("fcntl(F_GETFL) failed: %s (%d)",
                strerror(opal_socket_errno), opal_socket_errno));
    } else {
        flags |= O_NONBLOCK;
        if (fcntl(btl_endpoint->endpoint_sd, F_SETFL, flags) < 0)
            BTL_ERROR(("fcntl(F_SETFL) failed: %s (%d)",
                strerror(opal_socket_errno), opal_socket_errno));
    }
    /* Create the send event in a persistent manner. */
    opal_event_set(opal_event_base, &btl_endpoint->endpoint_send_event,
            btl_endpoint->endpoint_sd,
            OPAL_EV_WRITE | OPAL_EV_PERSIST,
            mca_btl_tipc_endpoint_send_handler,
            btl_endpoint);

    if (opal_list_get_size(&btl_endpoint->endpoint_frags) > 0) {
        if (NULL == btl_endpoint->endpoint_send_frag)
            btl_endpoint->endpoint_send_frag = (mca_btl_tipc_frag_t*)
            opal_list_remove_first(&btl_endpoint->endpoint_frags);
        opal_event_add(&btl_endpoint->endpoint_send_event, 0);
    }
}

static int mca_btl_tipc_endpoint_recv_process_id(mca_btl_base_endpoint_t* btl_endpoint) {
    orte_process_name_t guid;
    mca_btl_tipc_proc_t* btl_proc = btl_endpoint->endpoint_proc;

    if ((mca_btl_tipc_endpoint_recv_blocking(btl_endpoint, &guid, sizeof (orte_process_name_t))) != sizeof (orte_process_name_t)) {
        return OMPI_ERR_UNREACH;
    }
    ORTE_PROCESS_NAME_NTOH(guid);
    /* compare this to the expected values */
    if (OPAL_EQUAL != orte_util_compare_name_fields(ORTE_NS_CMP_ALL,
            &btl_proc->proc_ompi->proc_name,
            &guid)) {
        BTL_ERROR(("received unexpected process identifier %s",
                ORTE_NAME_PRINT(&guid)));
        mca_btl_tipc_endpoint_close(btl_endpoint);
        return OMPI_ERR_UNREACH;
    }

    DEBUG_INFO("process id confirmed\n");
    return OMPI_SUCCESS;
}

/*
 * A blocking recv on a non-blocking socket. Used to receive the small amount of connection
 * information that identifies the endpoints endpoint.
 */
static int mca_btl_tipc_endpoint_recv_blocking(mca_btl_base_endpoint_t* btl_endpoint, void* data, size_t size) {
    unsigned char* ptr = (unsigned char*) data;
    size_t cnt = 0;
    while (cnt < size) {
        int retval = recv(btl_endpoint->endpoint_sd, (char *) ptr + cnt, size - cnt, 0);

        /* remote closed connection */
        if (retval == 0) {
            mca_btl_tipc_endpoint_close(btl_endpoint);
            return -1;
        }
        /* socket is non-blocking so handle errors */
        if (retval < 0) {
            if (opal_socket_errno != EINTR && opal_socket_errno != EAGAIN && opal_socket_errno != EWOULDBLOCK) {
#if ENABLE_DEBUG_INFO
                BTL_ERROR(("recv(%d) failed: %s (%d)",
                        btl_endpoint->endpoint_sd, strerror(opal_socket_errno), opal_socket_errno));
#endif
                mca_btl_tipc_endpoint_close(btl_endpoint);
                return -1;
            }
            continue;
        }
        cnt += retval;
    }
    return cnt;
}

bool mca_btl_tipc_endpoint_service_exist(__u32 name_type, __u32 name_instance, int wait) {

    struct sockaddr_tipc topsrv;
    struct tipc_subscr subscr;
    struct tipc_event event;

    int sd = socket(AF_TIPC, SOCK_SEQPACKET, 0);


    memset(&topsrv, 0, sizeof (topsrv));
    topsrv.family = AF_TIPC;
    topsrv.addrtype = TIPC_ADDR_NAME;
    topsrv.addr.name.name.type = TIPC_TOP_SRV;
    topsrv.addr.name.name.instance = TIPC_TOP_SRV;

    /* Connect to topology server */

    if (0 > connect(sd, (struct sockaddr *) &topsrv, sizeof (topsrv))) {
        perror("Client: failed to connect to topology server");
        exit(1);
    }

    subscr.seq.type = htonl(name_type);
    subscr.seq.lower = htonl(name_instance);
    subscr.seq.upper = htonl(name_instance);
    subscr.timeout = htonl(wait);
    subscr.filter = htonl(TIPC_SUB_SERVICE);

    if (send(sd, &subscr, sizeof (subscr), 0) != sizeof (subscr)) {
        perror("Client: failed to send subscription");
        exit(1);
    }
    /* Now wait for the subscription to fire */

    if (recv(sd, &event, sizeof (event), 0) != sizeof (event)) {
        perror("Client: failed to receive event");
        exit(1);
    }
    close(sd);
    if (event.event != htonl(TIPC_PUBLISHED)) {
#if ENABLE_DEBUG_INFO
        printf("Client: server {%u,%u} not published within %u [s]\n",
                name_type, name_instance, wait / 1000);
#endif


        return false;
    } else {
        /*
                PRINT_INFO("Server published");
         */
    }
    return true;

}

void *mca_btl_tipc_endpoint_init_timer(mca_btl_base_endpoint_t* btl_endpoint) {
    /*
        opal_event_evtimer_set(opal_event_base,
                &btl_endpoint->endpoint_timeout_event,
                mca_btl_tipc_endpoint_complete_connect,
                btl_endpoint
                );
     */

    opal_event_set(opal_event_base,
            &btl_endpoint->endpoint_timeout_event,
            btl_endpoint->endpoint_sd,
            0,
            mca_btl_tipc_endpoint_send_handler,
            btl_endpoint);
}