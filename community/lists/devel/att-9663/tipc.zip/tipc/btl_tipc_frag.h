/* 
 * File:   btl_tipc_frag.h
 * Author: Xin He (xin.i.he@ericsson.com)
 *
 * Created on June 21, 2011, 11:40 AM
 */

#ifndef MCA_BTL_TIPC_FRAG_H
#define MCA_BTL_TIPC_FRAG_H


#define MCA_BTL_TIPC_FRAG_ALIGN (8)
#include "ompi_config.h"
#include "btl_tipc.h" 
#include "btl_tipc_hdr.h"


#define MCA_BTL_TIPC_FRAG_IOVEC_NUMBER  4

BEGIN_C_DECLS

/**
 * TIPC send fratipcent derived type.
 */
struct mca_btl_tipc_frag_t {
    mca_btl_base_descriptor_t base;
    mca_btl_base_segment_t segments[2];
    struct mca_btl_base_endpoint_t *endpoint;
    
    struct mca_btl_tipc_module_t* btl;
    struct iovec iov[MCA_BTL_TIPC_FRAG_IOVEC_NUMBER + 1];
    struct iovec *iov_ptr;
    size_t iov_cnt;
    size_t iov_idx;
    size_t size;
    int rc;
    ompi_free_list_t* my_list;
    struct mca_mpool_base_registration_t* registration;
    mca_btl_tipc_hdr_t hdr;
};


typedef struct mca_btl_tipc_frag_t mca_btl_tipc_frag_t;
OBJ_CLASS_DECLARATION(mca_btl_tipc_frag_t);

typedef struct mca_btl_tipc_frag_t mca_btl_tipc_frag_eager_t;

OBJ_CLASS_DECLARATION(mca_btl_tipc_frag_eager_t);

typedef struct mca_btl_tipc_frag_t mca_btl_tipc_frag_max_t;

OBJ_CLASS_DECLARATION(mca_btl_tipc_frag_max_t);

typedef struct mca_btl_tipc_frag_t mca_btl_tipc_frag_user_t;

OBJ_CLASS_DECLARATION(mca_btl_tipc_frag_user_t);


/*
 * Macros to allocate/return descriptors from module specific
 * free list(s).
 */

#define MCA_BTL_TIPC_FRAG_ALLOC_EAGER(frag, rc)                             \
{                                                                          \
    ompi_free_list_item_t *item;                                           \
    OMPI_FREE_LIST_GET(&mca_btl_tipc_component.tipc_frag_eager, item, rc);   \
    frag = (mca_btl_tipc_frag_t*) item;                                     \
}

#define MCA_BTL_TIPC_FRAG_RETURN_EAGER(btl, frag)              \
{                                                                  \
    OMPI_FREE_LIST_RETURN(&((mca_btl_tipc_module_t*)btl)->tipc_frag_eager, \
        (ompi_free_list_item_t*)(frag));                                \
}

#define MCA_BTL_TIPC_FRAG_ALLOC_MAX(frag, rc)                               \
{                                                                          \
    ompi_free_list_item_t *item;                                           \
    OMPI_FREE_LIST_GET(&mca_btl_tipc_component.tipc_frag_max, item, rc);     \
    frag = (mca_btl_tipc_frag_t*) item;                                     \
}

#define MCA_BTL_TIPC_FRAG_RETURN_MAX(btl, frag)                \
{                                                                  \
    OMPI_FREE_LIST_RETURN(&((mca_btl_tipc_module_t*)btl)->tipc_frag_max, \
        (ompi_free_list_item_t*)(frag));                                \
}


#define MCA_BTL_TIPC_FRAG_ALLOC_USER(frag, rc)                              \
{                                                                          \
    ompi_free_list_item_t *item;                                           \
    OMPI_FREE_LIST_GET(&mca_btl_tipc_component.tipc_frag_user, item, rc);    \
    frag = (mca_btl_tipc_frag_t*) item;                                     \
}

#define MCA_BTL_TIPC_FRAG_RETURN_USER(btl, frag)               \
{                                                                  \
    OMPI_FREE_LIST_RETURN(&((mca_btl_tipc_module_t*)btl)->tipc_frag_user, \
        (ompi_free_list_item_t*)(frag)); \
}

#define MCA_BTL_TIPC_FRAG_RETURN(frag)                                      \
{                                                                          \
    OMPI_FREE_LIST_RETURN(frag->my_list, (ompi_free_list_item_t*)(frag));  \
}

#define MCA_BTL_TIPC_FRAG_INIT_DST(frag,ep)                                 \
do {                                                                       \
    frag->rc = 0;                                                          \
    frag->btl = ep->endpoint_btl;                                          \
    frag->endpoint = ep;                                                   \
    frag->iov[0].iov_len = sizeof(frag->hdr);                              \
    frag->iov[0].iov_base = (IOVBASE_TYPE*)&frag->hdr;                     \
    frag->iov_cnt = 1;                                                     \
    frag->iov_idx = 0;                                                     \
    frag->iov_ptr = frag->iov;                                             \
    frag->base.des_src = NULL;                                             \
    frag->base.des_dst_cnt = 0;                                            \
    frag->base.des_dst = frag->segments;                                   \
    frag->base.des_dst_cnt = 1;                                            \
} while(0)


bool mca_btl_tipc_frag_send(mca_btl_tipc_frag_t* frag, int sd);
bool mca_btl_tipc_frag_recv(mca_btl_tipc_frag_t*, int sd);


END_C_DECLS
#endif


