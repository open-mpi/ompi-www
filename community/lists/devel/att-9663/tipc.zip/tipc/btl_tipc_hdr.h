/* 
 * File:   btl_tipc_hdr.h
 * Author: Xin He <xin.i.he@ericsson.com>
 *
 * Created on July 4, 2011, 11:02 AM
 */

#ifndef BTL_TIPC_HDR_H
#define	BTL_TIPC_HDR_H

#include "ompi_config.h"
#include "ompi/mca/btl/base/base.h"
#include "btl_tipc.h" 

BEGIN_C_DECLS

/**
 * TIPC header.
 */

#define MCA_BTL_TIPC_HDR_TYPE_SEND 1
#define MCA_BTL_TIPC_HDR_TYPE_PUT  2
#define MCA_BTL_TIPC_HDR_TYPE_GET  3

struct mca_btl_tipc_hdr_t {
    mca_btl_base_header_t base;
    uint8_t  type;
    uint16_t count;
    uint32_t size; 
}; 
typedef struct mca_btl_tipc_hdr_t mca_btl_tipc_hdr_t; 

#define MCA_BTL_TIPC_HDR_HTON(hdr)     \
    do {                              \
        hdr.count = htons(hdr.count); \
        hdr.size = htonl(hdr.size);   \
    } while (0)

#define MCA_BTL_TIPC_HDR_NTOH(hdr)     \
    do {                              \
        hdr.count = ntohs(hdr.count); \
        hdr.size = ntohl(hdr.size);   \
    } while (0)

END_C_DECLS

#endif	/* BTL_TIPC_HDR_H */

