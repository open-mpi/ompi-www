#include "ompi_config.h"
#include <string.h>
#include "opal/class/opal_bitmap.h"
#include "ompi/mca/btl/btl.h"

#include "btl_tipc.h"
#include "btl_tipc_frag.h" 
#include "btl_tipc_proc.h"
#include "btl_tipc_endpoint.h"
#include "opal/datatype/opal_convertor.h" 
#include "ompi/mca/btl/base/btl_base_error.h"
#include "opal/opal_socket_errno.h"
#include "ompi/mca/mpool/base/base.h" 
#include "ompi/mca/mpool/mpool.h" 
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include "ompi/runtime/ompi_module_exchange.h"

#include <fcntl.h>





/*
 *  Called by MCA framework to open the component, registers
 *  component parameters.
 */

mca_btl_tipc_component_t mca_btl_tipc_component = {
    {
        /* First, the mca_base_component_t struct containing meta information
           about the component itself */

        {
            MCA_BTL_BASE_VERSION_2_0_0,
            "tipc", /* MCA component name */
            OMPI_MAJOR_VERSION, /* MCA component major version */
            OMPI_MINOR_VERSION, /* MCA component minor version */
            OMPI_RELEASE_VERSION, /* MCA component release version */
            mca_btl_tipc_component_open, /* component open */
            mca_btl_tipc_component_close, /* component close */
            NULL, /* component query */
            NULL, /* component register */
        },
        {
            /* The component is not checkpoint ready */
            MCA_BASE_METADATA_PARAM_NONE
        },

        mca_btl_tipc_component_init,
        mca_btl_tipc_component_progress,
    }
};

static inline int mca_btl_tipc_param_register_int(
        const char* param_name,
        const char* help_string,
        int default_value) {
    int value;
    mca_base_param_reg_int(&mca_btl_tipc_component.super.btl_version,
            param_name, help_string, false, false,
            default_value, &value);
    return value;
}

struct mca_btl_tipc_event_t {
    opal_list_item_t item;
    opal_event_t event;
};
typedef struct mca_btl_tipc_event_t mca_btl_tipc_event_t;

static void mca_btl_tipc_event_construct(mca_btl_tipc_event_t* event) {
    OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
    opal_list_append(&mca_btl_tipc_component.tipc_events, &event->item);
    OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);
}

static void mca_btl_tipc_event_destruct(mca_btl_tipc_event_t* event) {
    OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
    opal_list_remove_item(&mca_btl_tipc_component.tipc_events, &event->item);
    OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);
}

OBJ_CLASS_INSTANCE(
        mca_btl_tipc_event_t,
        opal_list_item_t,
        mca_btl_tipc_event_construct,
        mca_btl_tipc_event_destruct);


/*
 * functions for receiving event callbacks
 */
static void mca_btl_tipc_component_recv_handler(int, short, void*);
static void mca_btl_tipc_component_accept_handler(int, short, void*);

int mca_btl_tipc_component_open(void) {
    /*just tell mca this btl is runnable for now*/
    /*
        enable_debug_info =
                mca_btl_tipc_param_register_int("enable_debug_info",
                "Set this value to 1 will print out debug information", 0);
     */
    mca_btl_tipc_component.tipc_num_btls = 0;
    mca_btl_tipc_component.tipc_btls = NULL;

    /*default value, adapted from tcp*/
    mca_btl_tipc_component.tipc_free_list_num = 8;
    mca_btl_tipc_component.tipc_free_list_max = -1;
    mca_btl_tipc_component.tipc_free_list_inc = 32;
    mca_btl_tipc_component.tipc_rcvbuf = 128 * 1024;
    mca_btl_tipc_component.tipc_sndbuf = 128 * 1024;

    /* initialize objects */
    OBJ_CONSTRUCT(&mca_btl_tipc_component.tipc_lock, opal_mutex_t);
    OBJ_CONSTRUCT(&mca_btl_tipc_component.tipc_procs, opal_hash_table_t);
    OBJ_CONSTRUCT(&mca_btl_tipc_component.tipc_events, opal_list_t);
    OBJ_CONSTRUCT(&mca_btl_tipc_component.tipc_frag_eager, ompi_free_list_t);
    OBJ_CONSTRUCT(&mca_btl_tipc_component.tipc_frag_max, ompi_free_list_t);
    OBJ_CONSTRUCT(&mca_btl_tipc_component.tipc_frag_user, ompi_free_list_t);
    opal_hash_table_init(&mca_btl_tipc_component.tipc_procs, 256);

    mca_btl_tipc_module.super.btl_exclusivity = MCA_BTL_EXCLUSIVITY_LOW + 100;
    mca_btl_tipc_module.super.btl_eager_limit = 64 * 1024;
    mca_btl_tipc_module.super.btl_rndv_eager_limit = 32 * 1024;
    mca_btl_tipc_module.super.btl_max_send_size = 32 * 1024;
    mca_btl_tipc_module.super.btl_rdma_pipeline_send_length = 64 * 1024;
    mca_btl_tipc_module.super.btl_rdma_pipeline_frag_size = INT_MAX;
    mca_btl_tipc_module.super.btl_min_rdma_pipeline_size = 0;
    /*
        mca_btl_tipc_module.super.btl_flags = MCA_BTL_FLAGS_PUT |
                MCA_BTL_FLAGS_SEND_INPLACE |
                MCA_BTL_FLAGS_NEED_CSUM |
                MCA_BTL_FLAGS_NEED_ACK |
                MCA_BTL_FLAGS_HETEROGENEOUS_RDMA;
     */
    mca_btl_tipc_module.super.btl_flags = MCA_BTL_FLAGS_SEND_INPLACE |
            MCA_BTL_FLAGS_NEED_CSUM |
            MCA_BTL_FLAGS_NEED_ACK |
            MCA_BTL_FLAGS_HETEROGENEOUS_RDMA;

    mca_btl_tipc_module.super.btl_bandwidth = 1000;
    mca_btl_tipc_module.super.btl_latency = 0;
    return OMPI_SUCCESS;
}

int mca_btl_tipc_component_close() {
    opal_list_item_t* item;
    opal_list_item_t* next;

    if (NULL != mca_btl_tipc_component.tipc_btls)
        free(mca_btl_tipc_component.tipc_btls);

    if (mca_btl_tipc_component.tipc_listen_sd >= 0) {
        opal_event_del(&mca_btl_tipc_component.tipc_recv_event);
        close(mca_btl_tipc_component.tipc_listen_sd);
        mca_btl_tipc_component.tipc_listen_sd = -1;
    }


    /* cleanup any pending events */
    OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
    if (!opal_list_is_empty(&mca_btl_tipc_component.tipc_events)) {
        for (item = opal_list_get_first(&mca_btl_tipc_component.tipc_events);
                item != opal_list_get_end(&mca_btl_tipc_component.tipc_events);
                item = next) {
            mca_btl_tipc_event_t* event = (mca_btl_tipc_event_t*) item;
            next = opal_list_get_next(item);
            opal_event_del(&event->event);
            DEBUG_INFO("event in tipc_events deleted");
            OBJ_RELEASE(event);
        }
    }
    OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);

    /* release resources */
    OBJ_DESTRUCT(&mca_btl_tipc_component.tipc_procs);
    OBJ_DESTRUCT(&mca_btl_tipc_component.tipc_events);
    OBJ_DESTRUCT(&mca_btl_tipc_component.tipc_frag_eager);
    OBJ_DESTRUCT(&mca_btl_tipc_component.tipc_frag_max);
    OBJ_DESTRUCT(&mca_btl_tipc_component.tipc_frag_user);
    OBJ_DESTRUCT(&mca_btl_tipc_component.tipc_lock);
    DEBUG_INFO("done mca_btl_tipc_component_close");

#if 0 & ENABLE_DEBUG_INFO
    /*print out the status of all registered events*/
    FILE *fp;
    fp = fopen("tipc_events.txt", "w");
    event_base_dump_events(opal_event_base->base, fp);
#endif
    return OMPI_SUCCESS;
}

int mca_btl_tipc_component_get_server_type() {
    time_t t;
    srand((unsigned) time(&t));
    int y = 20000;
    int x = 10000;
    int type = rand() % (y - x + 1) + x;


    return type + getpid();
}

int mca_btl_tipc_create_btl() {
    mca_btl_tipc_component.tipc_btls = (mca_btl_tipc_module_t**) malloc(sizeof (mca_btl_tipc_module_t *));
    mca_btl_tipc_component.tipc_btls[mca_btl_tipc_component.tipc_num_btls] = (struct mca_btl_tipc_module_t *) malloc(sizeof (mca_btl_tipc_module_t));
    struct mca_btl_tipc_module_t* btl = mca_btl_tipc_component.tipc_btls[mca_btl_tipc_component.tipc_num_btls];
    mca_btl_tipc_component.tipc_num_btls++;
    memcpy(btl, &mca_btl_tipc_module, sizeof (mca_btl_tipc_module));
    OBJ_CONSTRUCT(&btl->tipc_endpoints, opal_list_t);
    return OMPI_SUCCESS;
}

static int mca_btl_tipc_component_create_listen() {
    /*create a listen socket for incoming connections */
    /*
     * set the socket into non-blocking mode
     */
    struct sockaddr_tipc server_addr;
    int listener_sd;
    listener_sd = socket(AF_TIPC, SOCK_STREAM, 0);
    int flags;
    mca_btl_tipc_component.tipc_listen_sd = listener_sd;
#if ENABLE_DEBUG_INFO
    printf("Process: %d, Filename: %s, line: %d,socket: %d\n", getpid(), __FILE__, __LINE__, listener_sd);
#endif 
    if (listener_sd < 0) {
        perror("Server: unable to create socket\n");
        exit(1);
    }

    mca_btl_tipc_set_socket_options(listener_sd);

    server_addr.family = AF_TIPC;
    server_addr.addrtype = TIPC_ADDR_NAMESEQ;
    server_addr.addr.nameseq.type = mca_btl_tipc_component_get_server_type();
#if ENABLE_DEBUG_INFO
    printf("Process: %d, Filename: %s, line: %d,Local info: %d\n", getpid(), __FILE__, __LINE__, server_addr.addr.nameseq.type);
#endif    
    server_addr.addr.nameseq.lower = SERVER_INST;
    server_addr.addr.nameseq.upper = SERVER_INST;
    server_addr.scope = TIPC_ZONE_SCOPE;

    if (NULL == mca_btl_tipc_component.tipc_local)
        mca_btl_tipc_component.tipc_local = mca_btl_tipc_proc_create(ompi_proc_local());

    mca_btl_tipc_component.tipc_local->proc_addrs = (struct sockaddr_tipc *)
            malloc(sizeof (struct sockaddr_tipc));
    memcpy(mca_btl_tipc_component.tipc_local->proc_addrs,
            &server_addr,
            sizeof (struct sockaddr_tipc));

    if (bind(listener_sd, (struct sockaddr *) &server_addr,
            sizeof (server_addr))) {
        perror("Server: failed to bind port name\n");
        exit(1);
    }

    if (0 != listen(listener_sd, 0)) {
        perror("Server: failed to listen\n");
        exit(1);
    }
    
    /* set socket up to be non-blocking, otherwise accept could block */
    if ((flags = fcntl(listener_sd, F_GETFL, 0)) < 0) {
        BTL_ERROR(("fcntl(F_GETFL) failed: %s (%d)", strerror(opal_socket_errno), opal_socket_errno));
        close(listener_sd);
        return OMPI_ERROR;
    } else {
        flags |= O_NONBLOCK;
        if (fcntl(listener_sd, F_SETFL, flags) < 0) {
            BTL_ERROR(("fcntl(F_SETFL) failed: %s (%d)",
                    strerror(opal_socket_errno), opal_socket_errno));
            close(listener_sd);
            return OMPI_ERROR;
        }
    }
    /* register listen port  with libevent*/
    opal_event_set(opal_event_base, &mca_btl_tipc_component.tipc_recv_event,
            mca_btl_tipc_component.tipc_listen_sd,
            OPAL_EV_READ | OPAL_EV_PERSIST,
            mca_btl_tipc_component_accept_handler,
            0);
    opal_event_add(&mca_btl_tipc_component.tipc_recv_event, 0);
    return OMPI_SUCCESS;
}

static int mca_btl_tipc_component_exchange(void) {
    int rc = ompi_modex_send(&mca_btl_tipc_component.super.btl_version,
            mca_btl_tipc_component.tipc_local->proc_addrs,
            sizeof (struct sockaddr_tipc));
    return rc;
}

mca_btl_base_module_t** mca_btl_tipc_component_init(int *num_btl_modules,
        bool enable_progress_threads,
        bool enable_mpi_threads) {
    *num_btl_modules = 0;
    mca_btl_base_module_t **btls;

    /* Initiate BTL modules here. For Tipc, there should be only one module even
     * there are more than 1 eths.

    /*
        printf("ompi_free_list_init_new");
     */
    ompi_free_list_init_new(&mca_btl_tipc_component.tipc_frag_eager,
            sizeof (mca_btl_tipc_frag_eager_t) +
            mca_btl_tipc_module.super.btl_eager_limit,
            opal_cache_line_size,
            OBJ_CLASS(mca_btl_tipc_frag_eager_t),
            0, opal_cache_line_size,
            mca_btl_tipc_component.tipc_free_list_num,
            mca_btl_tipc_component.tipc_free_list_max,
            mca_btl_tipc_component.tipc_free_list_inc,
            NULL);
    ompi_free_list_init_new(&mca_btl_tipc_component.tipc_frag_max,
            sizeof (mca_btl_tipc_frag_max_t) +
            mca_btl_tipc_module.super.btl_max_send_size,
            opal_cache_line_size,
            OBJ_CLASS(mca_btl_tipc_frag_max_t),
            0, opal_cache_line_size,
            mca_btl_tipc_component.tipc_free_list_num,
            mca_btl_tipc_component.tipc_free_list_max,
            mca_btl_tipc_component.tipc_free_list_inc,
            NULL);
    ompi_free_list_init_new(&mca_btl_tipc_component.tipc_frag_user,
            sizeof (mca_btl_tipc_frag_user_t),
            opal_cache_line_size,
            OBJ_CLASS(mca_btl_tipc_frag_user_t),
            0, opal_cache_line_size,
            mca_btl_tipc_component.tipc_free_list_num,
            mca_btl_tipc_component.tipc_free_list_max,
            mca_btl_tipc_component.tipc_free_list_inc,
            NULL);


    /*Create a TIPC BTL instance*/
    mca_btl_tipc_create_btl();

    
    btls = (mca_btl_base_module_t **) malloc(sizeof (mca_btl_base_module_t*));
    if (NULL == btls) {
        return NULL;
    }

    if (mca_btl_tipc_component_create_listen() != OMPI_SUCCESS)
        return 0;

    /* publish TIPC parameters with the MCA framework */
    mca_btl_tipc_component_exchange();

    memcpy(btls, mca_btl_tipc_component.tipc_btls, mca_btl_tipc_component.tipc_num_btls * sizeof (mca_btl_tipc_module_t*));
    *num_btl_modules = mca_btl_tipc_component.tipc_num_btls;

    if (btls == NULL)
        DEBUG_INFO("btl==NULL\n");

    return btls;
}

int mca_btl_tipc_component_progress() {
    return 0;
}

void mca_btl_tipc_component_accept_handler(int listener_sd, short ignored, void* unused) {
    while (true) {
        OPAL_THREAD_LOCK(&mca_btl_tipc_component.tipc_lock);
        int peer_sd = accept(listener_sd, 0, 0);
        OPAL_THREAD_UNLOCK(&mca_btl_tipc_component.tipc_lock);
        if (peer_sd < 0) {
            if (opal_socket_errno == EINTR)
                continue;
            if (opal_socket_errno != EAGAIN && opal_socket_errno != EWOULDBLOCK)
                BTL_ERROR(("accept() failed: %s (%d).",
                    strerror(opal_socket_errno), opal_socket_errno));
            return;
        }
        DEBUG_INFO("mca_btl_tipc_component_accept_handler");
#if ENABLE_DEBUG_INFO
        printf("accept socket: %d @ %d\n",peer_sd,listener_sd);
#endif
        mca_btl_tipc_set_socket_options(peer_sd);
        /* wait for receipt of peers process identifier to complete this connection */
        mca_btl_tipc_event_t *event;
        event = OBJ_NEW(mca_btl_tipc_event_t);
        opal_event_set(opal_event_base,
                &event->event,
                peer_sd,
                OPAL_EV_READ,
                mca_btl_tipc_component_recv_handler, 
                event);
        opal_event_add(&event->event, 0);
    }
}

static void mca_btl_tipc_component_recv_handler(int sd, short flags, void* user) {
    orte_process_name_t guid;
    struct sockaddr_storage addr;
    int retval;
    mca_btl_tipc_proc_t* btl_proc;
    opal_socklen_t addr_len = sizeof (addr);
    
    mca_btl_tipc_event_t *event = (mca_btl_tipc_event_t *) user;
    opal_event_del(&event->event);
    OBJ_RELEASE(event);

    /* recv the process identifier */
    retval = recv(sd, (char *) &guid, sizeof (guid), 0);

    if (retval != sizeof (guid)) {
        DEBUG_INFO("socket close on error");
#if ENABLE_DEBUG_INFO
        printf("sd = %d, retval = %d sizeof(guid)=%d guid.jobid=%d\n",sd, retval,sizeof(guid),guid.jobid);
#endif
        close(sd);
        return;
    }
    ORTE_PROCESS_NAME_NTOH(guid);

    /* now set socket up to be non-blocking */
    if ((flags = fcntl(sd, F_GETFL, 0)) < 0) {
        BTL_ERROR(("fcntl(F_GETFL) failed: %s (%d)",
                strerror(opal_socket_errno), opal_socket_errno));
    } else {
        flags |= O_NONBLOCK;
        if (fcntl(sd, F_SETFL, flags) < 0) {
            BTL_ERROR(("fcntl(F_SETFL) failed: %s (%d)",
                    strerror(opal_socket_errno), opal_socket_errno));
        }
    }

    /* lookup the corresponding process */
    btl_proc = mca_btl_tipc_proc_lookup(&guid);
    if (NULL == btl_proc) {
        close(sd);
        DEBUG_INFO("Unable to find the process id");
        return;
    } else {
        DEBUG_INFO("Find the process");
    }

    /* lookup peer address */
    if (getpeername(sd, (struct sockaddr*) &addr, &addr_len) != 0) {
        BTL_ERROR(("getpeername() failed: %s (%d)",
                strerror(opal_socket_errno), opal_socket_errno));
        close(sd);
        return;
    }

    /* are there any existing peer instances will to accept this connection */
    if (mca_btl_tipc_proc_accept(btl_proc, (struct sockaddr*) &addr, sd) == false) {
        close(sd);
        DEBUG_INFO("socket close on error");
        return;
    }
}
