//****************************************************************************
// "NetPIPE" -- Network Protocol Independent Performance Evaluator.          *
// Copyright 1997, 1998 Iowa State University Research Foundation, Inc.      *
// NetPIPE is free software distrubuted under the GPL license.               *
// It is currently being developed Fall 2014- by Dave Turner at KSU          *
// Email: DrDaveTurner@gmail.com                                             *
//****************************************************************************
#include    "netpipe.h"
#include    <fcntl.h>

#if defined (MPLITE)
#include "mplite.h"
#endif


int doing_reset = 0;

void Init(ArgStruct *p, int* pargc, char*** pargv)
{
   p->reset_conn = 0; /* Default to not resetting connection */
   p->prot.sndbufsz = p->prot.rcvbufsz = 0;
   p->tr = 0;     /* The transmitter will be set using the -h host flag. */
   p->rcv = 1;
}

void Setup(ArgStruct *p)
{

   int i, j, bound, fs;
   FILE *fd;
   struct sockaddr_in *lsdout;      /* ptr to sockaddr_in in ArgStruct */
   char *myhostname, *otherhostname, *dot;


      /* allocate space for the list of hosts and their port numbers */

   p->host = (char **) malloc( p->nprocs * sizeof(char *) );
   for( i=0; i<p->nprocs; i++ ) 
      p->host[i] = (char *) malloc( 100 * sizeof(char) );

   p->port = (int *) malloc( p->nprocs * sizeof( int ) );

      /* Read the hostfile */

   if( p->hostfile == NULL ) {             /* No hostfile */

      fprintf(stderr, "You must use <-H hostfile> to specify a hostfile\n");
      exit(0);

   } else {

      if( (fd = fopen( p->hostfile, "r")) == NULL ) {
         fprintf(stderr, "%d Could not open the hostfile |%s| (errno=%d)\n",
                 p->myproc, p->hostfile, errno );
         exit(0);
      }

      for( i=0; i<p->nprocs; i++ ) {
         fs = fscanf( fd, "%s", p->host[i] );

            /* Set the port uniquely for each process on an SMP box.
             * For SMP procs, myproc must be set on input using a comma
             * after the hostfilename <-H hostfile,proc#>.  The nplaunch 
             * script does this automatically. */

         p->port[i] = DEFPORT;

         for( j=0; j<i; j++ ) 
            if( ! strcmp( p->host[j], p->host[i] ) ) p->port[i]++;

         if( p->port[i] > MAXPORT ) {
            fprintf(stderr, "%d NetPIPE: Port for node %d is above MAXPORT=%d\n",
                    p->myproc, i, MAXPORT);
            fprintf(stderr, "    Change MAXPORT in src/netpipe.h and recompile\n");
            exit(0);
         }

         if( p->myproc < 0 ) {      /* myproc not set yet, hope this is not SMP */

            myhostname = (char *) malloc( 100 );
            gethostname( myhostname, 100);
            if( (dot=strstr( myhostname, "." )) != NULL ) *dot = '\0';

            otherhostname = (char *) malloc( 100 );
            strcpy( otherhostname, p->host[i] );
            if( (dot=strstr( otherhostname, "." )) != NULL ) *dot = '\0';

            if( ! strcmp( myhostname, otherhostname ) ) p->myproc = i;

            if( p->port[i] != DEFPORT ) {
               fprintf(stderr, "%d NetPIPE: The process number must be specified for SMP nodes\n", p->myproc);
               fprintf(stderr, "            using <-H hostfile,proc#>.  nplaunch does this automatically\n");
               exit(0);
            }
         }
      }
   }

   if( p->myproc == 0 ) p->master = 1;

   if( p->myproc < 0 || p-> myproc >= p->nprocs ) {
      fprintf(stderr, "NetPIPE: myproc=%d was not set properly\n", p->myproc);
      exit(0);
   }

      /* Set the first half to be transmitters */

   p->tr = p->rcv = 0;
   if( p->myproc < p->nprocs/2 ) p->tr = 1;
   else p->rcv = 1;

   p->dest = p->source = p->nprocs - 1 - p->myproc;


      /* Now initialize the socket structures */

   p->comm_sd = malloc( p->nprocs * sizeof( int ) );
   for( i=0; i<p->nprocs; i++ ) p->comm_sd[i] = 0;

      /* Create the listen socket, for any interface on my port */

   lsdout = &(p->prot.sdout);
   bzero((char *) lsdout, sizeof(*lsdout));
   lsdout->sin_family      = AF_INET;
   lsdout->sin_addr.s_addr = htonl(INADDR_ANY);
   lsdout->sin_port        = htons(p->port[p->myproc]);

   p->serv_sd = create_socket( p );  /* This will be the listening socket */

   bound = bind(p->serv_sd, (struct sockaddr *) lsdout, sizeof(*lsdout));

   if( bound != 0 ) {
      fprintf(stderr,"%d NetPIPE: bind on local address failed! errno=%d\n",
              p->myproc, errno);
      exit(0);
   }

   listen(p->serv_sd, 5); /* Set the socket to listen for incoming connections */

   establish(p);                               /* Establish connections */
}   

   /* Create a generic socket */

int create_socket(ArgStruct *p)
{
   int sd, one=1, sizeofint=sizeof(int), send_size, recv_size;
   static int print_once = 1;
   struct protoent *proto;

   if ( (sd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ){
      fprintf(stderr,"NetPIPE: can't open the stream socket! errno=%d\n", errno);
      exit(0);
   }

   if( ! (proto=getprotobyname("tcp")) ){
      fprintf(stderr,"NetPIPE: protocol 'tcp' unknown!\n");
      exit(0);
   }

       /* Attempt to set TCP_NODELAY */

   if( setsockopt(sd, proto->p_proto, TCP_NODELAY, (const void *) &one, sizeof(one)) < 0) {
      fprintf(stderr,"NetPIPE: setsockopt: TCP_NODELAY failed! errno=%d\n", errno);
      exit(0);
   }

   if(setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (const void *) &one, sizeof(one)) < 0) {
      printf("NetPIPE: setsockopt: SO_REUSEADDR failed! errno=%d\n", errno);
      exit(0);
   }

      /* If requested, set the send and receive buffer sizes */

   if(p->prot.sndbufsz > 0) {

      if(setsockopt(sd, SOL_SOCKET, SO_SNDBUF, 
          (const void *) &(p->prot.sndbufsz), sizeof(p->prot.sndbufsz)) < 0) {

         fprintf(stderr,"NetPIPE: setsockopt: SO_SNDBUF failed! errno=%d\n", errno);
         fprintf(stderr,"You may have asked for a buffer larger than the system can handle\n");
         exit(0);

      }

      if(setsockopt(sd, SOL_SOCKET, SO_RCVBUF, 
          (const void *) &(p->prot.rcvbufsz), sizeof(p->prot.rcvbufsz)) < 0) {

         fprintf(stderr,"NetPIPE: setsockopt: SO_RCVBUF failed! errno=%d\n", errno);
         fprintf(stderr,"You may have asked for a buffer larger than the system can handle\n");
         exit(0);
      }
   }

   getsockopt(sd, SOL_SOCKET, SO_SNDBUF,
                   (char *) &send_size, (void *) &sizeofint);
   getsockopt(sd, SOL_SOCKET, SO_RCVBUF,
                   (char *) &recv_size, (void *) &sizeofint);

   if(!doing_reset && p->master && print_once) {
      fprintf(stderr,"Send and receive buffers are %d and %d bytes\n",
              send_size, recv_size);
      fprintf(stderr, "(A bug in Linux doubles the requested buffer sizes)\n");
      print_once = 0;
   }

   p->upper = send_size + recv_size;

   return sd;
} 

   /* Create a socket and connect it to the node specified */

static char buf[] = "      ";

void connect_to( ArgStruct *p, int node )
{
   int one = 1;
   socklen_t clen;
   struct protoent *proto;
   struct sockaddr_in *lsdin;      /* ptr to sockaddr_in in ArgStruct */
   struct hostent *addr;
   double t0 = myclock();

      /* Set the socket info for initiating connections */

   lsdin = &(p->prot.sdin);

   bzero((char *) lsdin, sizeof(*lsdin));

   if (atoi(p->host[node]) > 0) {                   /* Numerical IP address */

      lsdin->sin_family = AF_INET;
      lsdin->sin_addr.s_addr = inet_addr(p->host[node]);

   } else {

      if ((addr = gethostbyname(p->host[node])) == NULL){
         fprintf(stderr,"%d NetPIPE: invalid hostname '%s'\n",
                 p->myproc, p->host[node]);
         exit(0);
      }

      lsdin->sin_family = addr->h_addrtype;
      bcopy(addr->h_addr, (char*) &(lsdin->sin_addr.s_addr), addr->h_length);
   }

   lsdin->sin_port = htons(p->port[node]);

   clen = (socklen_t) sizeof(p->prot.sdin);

   p->comm_sd[node] = create_socket( p );

   while( connect(p->comm_sd[node], (struct sockaddr *) &(p->prot.sdin),
                   sizeof(p->prot.sdin)) < 0 ) {

      /* If we are doing a reset and we get a connection refused from
       * the connect() call, assume that the other node has not yet
       * gotten to its corresponding accept() call and keep trying until
       * we have success.
       */

      if( (!doing_reset || errno != ECONNREFUSED) && myclock()-t0 > 20.0 ) {
        fprintf(stderr,"%d NetPIPE: Cannot connect for 20 seconds! errno=%d\n",
               p->myproc, errno);
        exit(0);
      }

      sleep(1);
   }

   /* Do a read here to make sure the socket is completely connected. UNIX
    * socket implementations can potentially queue up socket connections on the
    * accepting end, even if the process there has not yet called accept().
    * Thus, we can get into some nasty race conditions if we're connecting a
    * bunch of sockets on different nodes. For example, running NetPIPE with 4
    * nodes, it's possible for some socket descriptors to get mixed up in the
    * establish function. */

   readFully(p, node, buf, strlen(buf)); 

   if(strcmp(buf, "SyncMe")!=0) {
      fprintf(stderr, "Error reading sync buffer in connect_to()\n");
      exit(-1);
   }
}

   /* Accept a connect from node on the listen socket */

void accept_from( ArgStruct *p, int node )
{
   int one = 1;
   socklen_t clen;
   struct protoent *proto;
   char buf[] = "SyncMe";
   
/*fprintf(stderr,"%d accept_from( %d %s )\n", p->myproc, node, p->host[node]);*/

   clen = (socklen_t) sizeof(p->prot.sdout);

   p->comm_sd[node] = accept(p->serv_sd, (struct sockaddr *) &(p->prot.sdout), &clen);

/*fprintf(stderr,"%d after accept()\n", p->myproc);*/

   if(p->comm_sd[node] < 0){
      fprintf(stderr,"%d NetPIPE: Accept Failed! errno=%d\n",p->myproc,errno);
      exit(0);
   }

      /* Attempt to set TCP_NODELAY. TCP_NODELAY may or may not be propagated
       * to accepted sockets.  */

   if( ! (proto = getprotobyname("tcp")) ){
      fprintf(stderr,"%d NetPIPE: unknown protocol!\n", p->myproc);
      exit(0);
   }

   if(setsockopt(p->comm_sd[node], proto->p_proto, TCP_NODELAY,
                 (const void *) &one, sizeof(one)) < 0) {

      fprintf(stderr,"setsockopt: TCP_NODELAY failed! errno=%d\n", errno);
      exit(0);
   }

   if(setsockopt(p->comm_sd[node], SOL_SOCKET, SO_REUSEADDR, (const void *) &one, sizeof(one)) < 0) {
      printf("NetPIPE: setsockopt: SO_REUSEADDR failed! errno=%d\n", errno);
      exit(0);
   }

     /* If requested, set the send and receive buffer sizes */

   if(p->prot.sndbufsz > 0) {

      if(setsockopt(p->comm_sd[node], SOL_SOCKET, SO_SNDBUF, 
          (const void *) &(p->prot.sndbufsz), sizeof(p->prot.sndbufsz)) < 0) {

         fprintf(stderr,"setsockopt: SO_SNDBUF failed! errno=%d\n", errno);
         exit(0);
      }
      if(setsockopt(p->comm_sd[node], SOL_SOCKET, SO_RCVBUF, 
          (const void *) &(p->prot.rcvbufsz), sizeof(p->prot.rcvbufsz)) < 0) {
         fprintf(stderr,"setsockopt: SO_RCVBUF failed! errno=%d\n", errno);
         exit(0);
      }
   }

   writeFully(p, node, buf, strlen(buf));
}

void establish(ArgStruct *p)
{
   int i, r;
   long socket_flags;

     /* First connect to my communication partner */

   if( p->tr ){

      connect_to( p, p->dest );

   } else {

      accept_from( p, p->source );

   }

      /* Now connect all to the master proc 0 */

   if( p->master ) {

      for( i=1; i<p->nprocs; i++ ) {

         if( i != p->dest ) connect_to( p, i );

      }

   } else if( p->dest != 0 ) {

      accept_from( p, 0 );

   }

      /* Make sockets non-blocking for CPU workload measurements */

   if( p->workload ) {

      socket_flags = fcntl(p->comm_sd[p->dest], F_GETFL, 0);
#if defined (FNONBLK)
      socket_flags = socket_flags + FNONBLK;
#elif defined (FNONBLOCK)
      socket_flags = socket_flags + FNONBLOCK;
#else
      socket_flags = socket_flags + O_NONBLOCK;
#endif

      r = fcntl(p->comm_sd[p->dest], F_SETFL, socket_flags);
   }
}

   /* Read once from the socket (used only for TestForCompletion) */

int readOnce(ArgStruct *p)
{
   int bytesRead, errno;

   bytesRead = read(p->comm_sd[p->source], (void *) p->r_ptr, p->bytesLeft);

/*fprintf(stderr,"%d readOnce %d of %d bytes\n", p->myproc, bytesRead, p->bufflen);*/

   if( bytesRead < 0 && errno == EWOULDBLOCK ) bytesRead = 0;

   if( bytesRead < 0 ) {
      fprintf(stderr,"%d NetPIPE: ReadOnce() error, read %d of %d (errno=%d)\n", 
              p->myproc, p->bufflen - p->bytesLeft, p->bufflen, errno);
      exit(0);
   }

   p->bytesLeft -= bytesRead;
   p->r_ptr += bytesRead;

   return bytesRead;
}


   /* Read p->bufflen from the socket until complete */

int readFully( ArgStruct *p, int node, void *buf, int nbytes )
{
   int bytesLeft = nbytes;
   char *ptr = (char *) buf;
   int bytesRead, errno;

   while (bytesLeft > 0 ) { 

      bytesRead = read(p->comm_sd[node], (void *) ptr, bytesLeft);

      if( bytesRead < 0 && errno == EWOULDBLOCK ) bytesRead = 0;

      if( bytesRead < 0 ) {
         fprintf(stderr,"%d NetPIPE: ReadFully() error, read %d of %d (errno=%d)\n", 
                 p->myproc, nbytes - bytesLeft, nbytes, errno);
         exit(0);
      }

      bytesLeft -= bytesRead;
      ptr += bytesRead;
   }

/*fprintf(stderr,"%d readFully %d bytes\n", p->myproc, nbytes);*/
   return nbytes;
}

   /* Write nbytes to the socket until complete */

int writeFully(ArgStruct *p, int node, void *buf, int nbytes)
{
   int bytesLeft = nbytes;
   char *ptr = (char *) buf;
   int bytesSent, errno;

/*fprintf(stderr,"%d writing %d to %d\n", p->myproc, nbytes, node);*/
   while (bytesLeft > 0 ) { 

      bytesSent = write(p->comm_sd[node], (void *) ptr, bytesLeft);
/*fprintf(stderr,"%d wrote %d of %d to %d\n", p->myproc, bytesSent, nbytes, node);*/

      if( bytesSent < 0 && errno == EWOULDBLOCK ) bytesSent = 0;

      if(bytesSent < 0) {
         fprintf(stderr,"%d NetPIPE: write to %d error, errno=%d\n", 
                 p->myproc, node, errno);
         exit(0);
      }

      bytesLeft -= bytesSent;
      ptr += bytesSent;
   }

   return nbytes;
}

   /* Global sync with the master node, then local sync with your comm pair */

static char s[] = "SyncMe", response[] = "      ";

void Sync(ArgStruct *p)
{
   int i;

      /* First do a global synchronization with the master proc 0
       * if there are multiple pairs. */

   if( p->master && p->nprocs > 2 ) {

         /* Read from each proc first */

      for( i=1; i<p->nprocs; i++ ) {

         strcpy( response, "      " );

         readFully(p, i, response, strlen(s));  /* Read from nbor */

         if( strncmp(s, response, strlen(s)) ) {
            fprintf(stderr,"NetPIPE: error reading synchronization string");
            exit(0);
         }
      }

         /* Write to each proc */

      for( i=1; i<p->nprocs; i++ ) {

         writeFully(p, i, s, strlen(s));

      }

   } else if( p->nprocs > 2 ) {

      writeFully(p, 0, s, strlen(s));

      strcpy( response, "      " );
      readFully( p, 0, response, strlen(s));

      if( strncmp(s, response, strlen(s)) ) {
         fprintf(stderr,"%d NetPIPE: error writing or reading sync string\n", p->myproc);
         exit(0);
      }
   }

      /* Now do a local sync with your comm pair. */

   writeFully(p, p->dest, s, strlen(s));

   strcpy( response, "      " );
   readFully( p, p->dest, response, strlen(s));

   if( strncmp(s, response, strlen(s)) ) {
      fprintf(stderr,"%d NetPIPE: error writing or reading sync string\n", p->myproc);
      exit(0);
   }
}

void PrepareToReceive(ArgStruct *p)
{
        /*
            The Berkeley sockets interface doesn't have a method to pre-post
            a buffer for reception of data.
        */
}

   /* Send the data segment to the proc I am paired with */

void SendData(ArgStruct *p)
{
   writeFully(p, p->dest, p->s_ptr, p->bufflen);
}

/* This function reads the socket buffers once then tests for message
 * completion.  It may need to be adapted to read multiple times until
 * 0 bytes is read.
 */

int TestForCompletion( ArgStruct *p )
{
   readOnce( p );

   if( p->bytesLeft == 0 ) return 1;   /* The message is complete */
   else                    return 0;   /* The message is incomplete */
}

void RecvData(ArgStruct *p)
{
   if( p->bytesLeft > 0 )   /* protect against re-read in CPU workload measurements */
      readFully( p, p->source, p->r_ptr, p->bufflen);
   else
      p->r_ptr = p->r_ptr_saved;
}

   /* Generic Gather routine (used to gather times) */

void Gather( ArgStruct *p, double *buf)
{
   int proc;

   if( p->master ) {   /* Gather the data from the other procs */

      for( proc=1; proc<p->nprocs; proc++ ) {

         buf++;

         readFully(p, proc, buf, sizeof(double));

      }

   } else {   /* Write my section to the master proc 0 */

      buf++;
         
      writeFully(p, 0, buf, sizeof(double));

   }
}

   /* Broadcast from master 0 to all other procs (used for nrepeat) */

void Broadcast(ArgStruct *p, unsigned int *buf)
{
   int proc;

   if( p->master ) {

      for( proc=1; proc<p->nprocs; proc++ ) {

         writeFully(p, proc, buf, sizeof(int));

      }

   } else {

      readFully(p, 0, buf, sizeof(int));

   }
}


void CleanUp(ArgStruct *p)
{
   int proc;

   Sync( p );

   for( proc=0; proc<p->nprocs; proc++) {

      if( p->comm_sd[proc] != 0 )  close(p->comm_sd[proc]);

   }

   close(p->serv_sd);
}


void Reset(ArgStruct *p)
{
  
     /* Reset sockets */

  if(p->reset_conn) {

    doing_reset = 1;

       /* Close the sockets */

    CleanUp(p);

       /* Now open and connect new sockets */

    Setup(p);

  }
}
