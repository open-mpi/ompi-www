//****************************************************************************
// "NetPIPE" -- Network Protocol Independent Performance Evaluator.          *
// Copyright 1997, 1998 Iowa State University Research Foundation, Inc.      *
// NetPIPE is free software distrubuted under the GPL license.               *
// It is currently being developed Fall 2014- by Dave Turner at KSU          *
// Email: DrDaveTurner@gmail.com                                             *
//****************************************************************************
#include    "netpipe.h"
#include    <mpi.h>


/* Initialize vars in Init() that may be changed by parsing the command args */

void Init(ArgStruct *p, int* pargc, char*** pargv)
{
  p->source = 0;  /* Default source node */

  MPI_Init(pargc, pargv);
}

void Setup(ArgStruct *p)
{
   char s[255], *ptr;
   FILE *fd;
   int i, np, mp = -1, node, fs;

   MPI_Comm_rank(MPI_COMM_WORLD, &p->myproc);
   MPI_Comm_size(MPI_COMM_WORLD, &np);


   gethostname(s,253);
   if( s[0] != '.' ) {                 /* just print the base name */
      ptr = strchr( s, '.');
      if( ptr != NULL ) *ptr = '\0';
   }
   fprintf(stderr,"%d: %s\n",p->myproc,s);

   if( np != p->nprocs && p->nprocs != 2 ) {
      if( p->myproc == 0 ) {
         fprintf(stderr,"MPI_Comm_size doesn't match default or command line nprocs,\n");
         fprintf(stderr,"nprocs will be reset to %d in mpi.c#setup()\n",np);
      }
   }
   p->nprocs = np;

   if (p->nprocs < 2 || p->nprocs%2 == 1) {
      fprintf(stderr, "tcp.c: nprocs = %d must be even and at least 2\n", p->nprocs);
      exit(0);
   }

   p->dest = (p->nprocs - 1) - p->myproc;

       /* You can change the communication pairs using the <-H hostfile>
        * where hostfile has a listing of the new process numbers,
        * with the first and last communicating, etc.
        * In this code, it changes each procs myproc and dest.
        */

/* DDT - This could use better error checking on the input file */

   if( p->hostfile != NULL ) {

      if( (fd = fopen( p->hostfile, "r")) == NULL ) {
         fprintf(stderr, "Could not open the hostfile %s\n", p->hostfile );
         exit(0);
      }

      p->host = (char **) malloc( p->nprocs * sizeof(char *) );
      for( i=0; i<p->nprocs; i++ )
         p->host[i] = (char *) malloc( 100 * sizeof(char) );

      for( i=0; i<p->nprocs; i++ ) {
         fs = fscanf( fd, "%s", p->host[i]);
         if( atoi(p->host[i]) == p->myproc ) mp = i;
      }

      if( mp < 0 ) {
         fprintf(stderr, "%d NetPIPE: Error reading the hostfile, mp=%d\n",
                 p->myproc, mp);
         exit(0);
      }

      p->dest = atoi( p->host[ p->nprocs - 1 - mp ] );
/*fprintf(stderr,"%d proc mp=%d dest=%d\n", p->myproc, mp, p->dest);*/
      p->myproc = mp;

   }

       /* The first half are transmitters by default.  */

   p->tr = p->rcv = 0;
   if( p->myproc < p->nprocs/2 ) p->tr = 1;
   else p->rcv = 1;

       /* p->source may already have been set to -1 (MPI_ANY_SOURCE)
        * by specifying a -z on the command line.  If not, set the source
        * node normally. */

   if( p->source == 0 ) p->source = p->dest;

   if( p->bidir && p->myproc == 0 ) {
      fprintf(stderr,"MPI implementations do not have to guarantee message progress.\n");
      fprintf(stderr,"You may need to run using -a to avoid locking up.\n\n");
   }
}   

void Sync(ArgStruct *p)
{
    MPI_Barrier(MPI_COMM_WORLD);
}

static int recvPosted = 0;
static MPI_Request recvRequest;

void PrepareToReceive(ArgStruct *p)
{
   static int tag = 0;

   /* Providing a buffer for reception of data in advance of
    * the sender sending the data provides a major performance
    * boost on some implementations of MPI, particularly shared
    * memory implementations on the Cray T3E and Intel Paragon.
    */

   if (recvPosted) {
      fprintf(stderr,"Can't prepare to receive: outstanding receive!\n");
      exit(-1);
   }

   if( p->source < 0 ) {   /* Receive using MPI_ANY_SOURCE */

      MPI_Irecv(p->r_ptr, p->bufflen, MPI_BYTE, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &recvRequest);

   } else {

      MPI_Irecv(p->r_ptr, p->bufflen, MPI_BYTE, p->source, tag, MPI_COMM_WORLD, &recvRequest);

   }
   tag = (tag+1) % 100;
   recvPosted = -1;
}

void SendData(ArgStruct *p)
{
   static int tag = 0;

/*    char *cbuf = p->s_ptr;*/

/*fprintf(stderr,"%d putting %d bytes from %p to %d (%d %d %d)\n", */
/*        p->myproc, p->bufflen, p->s_ptr, p->dest, */
/*        cbuf[0], cbuf[p->bufflen/2], cbuf[p->bufflen-1]);*/

   if(p->syncflag)
      MPI_Ssend(p->s_ptr, p->bufflen, MPI_BYTE, p->dest, tag, MPI_COMM_WORLD);
   else
      MPI_Send( p->s_ptr, p->bufflen, MPI_BYTE, p->dest, tag, MPI_COMM_WORLD);

   tag = (tag+1) % 100;
}

int TestForCompletion( ArgStruct *p )
{
   int complete;

   MPI_Test( &recvRequest, &complete, MPI_STATUS_IGNORE );

   return complete;
}

void RecvData(ArgStruct *p)
{
   MPI_Status status;
   static int tag = 0;

/*   char *cbuf = p->r_ptr;*/

/*fprintf(stderr,"%d receiving %d bytes into %p (%d %d %d), expecting %d\n", */
/*        p->myproc, p->bufflen, p->r_ptr, */
/*        cbuf[0], cbuf[p->bufflen/2], cbuf[p->bufflen-1], (char) p->expected);*/

   if (recvPosted) {

      MPI_Wait(&recvRequest, &status);
      recvPosted = 0;

   } else {
      if( p->source < 0 ) {   /* Receive using MPI_ANY_SOURCE */

         MPI_Recv(p->r_ptr, p->bufflen, MPI_BYTE, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &status);

      } else {

         MPI_Recv(p->r_ptr, p->bufflen, MPI_BYTE, p->source, tag, MPI_COMM_WORLD, &status);

      }
   }
   tag = (tag+1) % 100;

/*fprintf(stderr,"%d received %d bytes into %p (%d %d %d), wanted %d\n", */
/*        p->myproc, p->bufflen, p->r_ptr, */
/*        cbuf[0], cbuf[p->bufflen/2], cbuf[p->bufflen-1], (char) p->expected);*/
}

   /* Gather the times from all procs to proc 0 for output */

void Gather(ArgStruct *p, double *buf)
{
   MPI_Gather( &buf[p->myproc], 1, MPI_DOUBLE, 
                buf,            1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
}

   /* Proc 0 sets nrepeats then broadcasts it to all procs */

void Broadcast(ArgStruct *p, unsigned int *nrepeat)
{
   MPI_Bcast(nrepeat, 1, MPI_INT, 0, MPI_COMM_WORLD);
}

void CleanUp(ArgStruct *p)
{
   MPI_Finalize();
}

void Reset(ArgStruct *p) { }
