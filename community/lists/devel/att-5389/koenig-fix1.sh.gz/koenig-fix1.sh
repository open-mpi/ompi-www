#!/bin/sh

echo "Modifying values from configure.ac..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_NEED_C_BOOL/OPAL_NEED_C_BOOL/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_WEAK_SYMBOLS/OPAL_HAVE_WEAK_SYMBOLS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_C_HAVE_WEAK_SYMBOLS/OPAL_C_HAVE_WEAK_SYMBOLS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_USE_STDBOOL_H/OPAL_USE_STDBOOL_H/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_SA_RESTART/OPAL_HAVE_SA_RESTART/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_VA_COPY/OPAL_HAVE_VA_COPY/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_UNDERSCORE_VA_COPY/OPAL_HAVE_UNDERSCORE_VA_COPY/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_PTRDIFF_TYPE/OPAL_PTRDIFF_TYPE/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_ptrdiff_t/opal_ptrdiff_t/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ALIGN_WORD_SIZE_INTEGERS/OPAL_ALIGN_WORD_SIZE_INTEGERS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_WANT_LIBLTDL/OPAL_WANT_LIBLTDL/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ENABLE_DLOPEN_SUPPORT/OPAL_ENABLE_DLOPEN_SUPPORT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_STDC_HEADERS/OPAL_STDC_HEADERS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_SYS_TIME_H/OPAL_HAVE_SYS_TIME_H/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_LONG_LONG/OPAL_HAVE_LONG_LONG/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_SYS_SYNCH_H/OPAL_HAVE_SYS_SYNCH_H/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_SIZEOF_BOOL/OPAL_SIZEOF_BOOL/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_SIZEOF_INT/OPAL_SIZEOF_INT/g" '{}'
##
echo "Modifying values from .../config/ompi_check_attributes.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_ATTRIBUTE/OPAL_HAVE_ATTRIBUTE/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_cv___attribute__/opal_cv___attribute__/g" '{}'
##
echo "Modifying values from .../config/ompi_check_ident.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e 's/OMPI_$1_USE_/OPAL_$1_USE_/g' '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_pragma_ident_happy/opal_pragma_ident_happy/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_ident_happy/opal_ident_happy/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_pragma_comment_happy/opal_pragma_comment_happy/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_static_const_char_happy/opal_static_const_char_happy/g" '{}'
##
echo "Modifying values from .../config/ompi_check_pthread_pids.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_THREADS_HAVE_DIFFERENT_PIDS/OPAL_THREADS_HAVE_DIFFERENT_PIDS/g" '{}'
##
echo "Modifying values from .../config/ompi_check_visibility.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_C_HAVE_VISIBILITY/OPAL_C_HAVE_VISIBILITY/g" '{}'
##
echo "Modifying values from .../config/ompi_config_asm.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_TEXT/OPAL_ASM_TEXT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_cv_asm_text/opal_cv_asm_text/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_GLOBAL/OPAL_ASM_GLOBAL/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_cv_asm_global/opal_cv_asm_global/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_LSYM/OPAL_ASM_LSYM/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_cv_asm_lsym/opal_cv_asm_lsym/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_GSYM/OPAL_ASM_GSYM/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_cv_asm_gsym/opal_cv_asm_gsym/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_LABEL_SUFFIX/OPAL_ASM_LABEL_SUFFIX/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_cv_asm_label_suffix/opal_cv_asm_label_suffix/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_ALIGN_LOG/OPAL_ASM_ALIGN_LOG/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_TYPE/OPAL_ASM_TYPE/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_cv_asm_type/opal_cv_asm_type/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_SIZE/OPAL_ASM_SIZE/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_asm_size/opal_asm_size/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_POWERPC_R_REGISTERS/OPAL_POWERPC_R_REGISTERS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_cv_asm_powerpc_r_reg/opal_cv_asm_powerpc_r_reg/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_C_GCC_INLINE_ASSEMBLY/OPAL_C_GCC_INLINE_ASSEMBLY/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_C_DEC_INLINE_ASSEMBLY/OPAL_C_DEC_INLINE_ASSEMBLY/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_C_XLC_INLINE_ASSEMBLY/OPAL_C_XLC_INLINE_ASSEMBLY/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_WANT_SMP_LOCKS/OPAL_WANT_SMP_LOCKS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASM_SUPPORT_64BIT/OPAL_ASM_SUPPORT_64BIT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASSEMBLY_FORMAT/OPAL_ASSEMBLY_FORMAT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ASSEMBLY_ARCH/OPAL_ASSEMBLY_ARCH/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_ASM_FILE/OPAL_HAVE_ASM_FILE/g" '{}'
##
echo "Modifying values from .../config/ompi_config_threads.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_POSIX_THREADS/OPAL_HAVE_POSIX_THREADS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_SOLARIS_THREADS/OPAL_HAVE_SOLARIS_THREADS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_THREADS_HAVE_DIFFERENT_PIDS/OPAL_THREADS_HAVE_DIFFERENT_PIDS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ENABLE_MPI_THREADS/OPAL_ENABLE_MPI_THREADS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ENABLE_PROGRESS_THREADS/OPAL_ENABLE_PROGRESS_THREADS/g" '{}'
##
echo "Modifying values from .../config/ompi_functions.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ARCH/OPAL_ARCH/g" '{}'
##
echo "Modifying values from .../config/ompi_setup_cc.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_C_HAVE_BUILTIN_EXPECT/OPAL_C_HAVE_BUILTIN_EXPECT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_C_HAVE_BUILTIN_PREFETCH/OPAL_C_HAVE_BUILTIN_PREFETCH/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_CC/OPAL_CC/g" '{}'
##
echo "Modifying values from .../config/ompi_configure_options.m4..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ENABLE_MEM_DEBUG/OPAL_ENABLE_MEM_DEBUG/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ENABLE_MEM_PROFILE/OPAL_ENABLE_MEM_PROFILE/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ENABLE_DEBUG/OPAL_ENABLE_DEBUG/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_WANT_PRETTY_PRINT_STACKTRACE/OPAL_WANT_PRETTY_PRINT_STACKTRACE/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ENABLE_PTY_SUPPORT/OPAL_ENABLE_PTY_SUPPORT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ENABLE_HETEROGENEOUS_SUPPORT/OPAL_ENABLE_HETEROGENEOUS_SUPPORT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_WANT_HOME_CONFIG_FILES/OPAL_WANT_HOME_CONFIG_FILES/g" '{}'
##
echo "Modifying values from .../opal/include/opal_config_bottom.h..."
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_THREADS/OPAL_HAVE_THREADS/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_THREAD_SUPPORT/OPAL_HAVE_THREAD_SUPPORT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ALIGNMENT_CHAR/OPAL_ALIGNMENT_CHAR/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ALIGNMENT_SHORT/OPAL_ALIGNMENT_SHORT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ALIGNMENT_INT/OPAL_ALIGNMENT_INT/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_ALIGNMENT_LONG/OPAL_ALIGNMENT_LONG/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_PATH_MAX/OPAL_PATH_MAX/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_DISABLE_ENABLE_MEM_DEBUG/OPAL_DISABLE_ENABLE_MEM_DEBUG/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_DEBUG_ZERO/OPAL_DEBUG_ZERO/g" '{}'
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/OMPI_HAVE_BROKEN_QSORT/OPAL_HAVE_BROKEN_QSORT/g" '{}'
##
echo "Updating filenames..."
echo "[NOTE: Change these to 'svn mv' when the change is for real]"
mv config/ompi_check_attributes.m4 config/opal_check_attributes.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_check_attributes.m4/opal_check_attributes.m4/g" '{}'
mv config/ompi_check_ident.m4 config/opal_check_ident.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_check_ident.m4/opal_check_ident.m4/g" '{}'
mv config/ompi_check_pthread_pids.m4 config/opal_check_pthread_pids.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_check_pthread_pids.m4/opal_check_pthread_pids.m4/g" '{}'
mv config/ompi_check_visibility.m4 config/opal_check_visibility.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_check_visibility.m4/opal_check_visibility.m4/g" '{}'
mv config/ompi_config_asm.m4 config/opal_config_asm.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_config_asm.m4/opal_config_asm.m4/g" '{}'
mv config/ompi_config_threads.m4 config/opal_config_threads.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_config_threads.m4/opal_config_threads.m4/g" '{}'
mv config/ompi_functions.m4 config/opal_functions.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_functions.m4/opal_functions.m4/g" '{}'
mv config/ompi_setup_cc.m4 config/opal_setup_cc.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_setup_cc.m4/opal_setup_cc.m4/g" '{}'
mv config/ompi_configure_options.m4 config/opal_configure_options.m4
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e "s/ompi_configure_options.m4/opal_configure_options.m4/g" '{}'
##
echo "Removing unnecessary #include lines..."
cd ompi/mca/btl
find . * -type f | grep -v '.svn' | xargs -I '{}' sed -i -e '/#include "ompi\/mca\/pml\/pml.h"/ d' '{}'
