#!/bin/sh 

autoreconf -ivf
