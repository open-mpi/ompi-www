/*
 * Copyright (c) 2006-2007      University of Houston. All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */
#ifndef ATF_DISPLAY_RESULT_
#define ATF_DISPLAY_RESULT_

int ATF_Display_Result();

#endif
