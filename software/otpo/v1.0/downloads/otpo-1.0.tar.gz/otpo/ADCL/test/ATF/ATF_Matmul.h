/*
 * Copyright (c) 2006-2007      University of Houston. All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */
#ifndef ATF_MATMUL_H
#define ATF_MATMUL_H


int ATF_Matmul_blocking(double ****, double ****);


#endif

