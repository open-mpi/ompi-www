#ifndef __ADCL_ALLREDUCE__
#define __ADCL_ALLREDUCE__

#define ADCL_TAG_ALLREDUCE 124

#endif
