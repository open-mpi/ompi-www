/*
 * Copyright (c) 2013-2014 Intel, Inc. All rights reserved.
 * $COPYRIGHT$
 * 
 * Additional copyrights may follow
 * 
 * $HEADER$
 */

#ifndef ORTE_ESS_OPAL_H
#define ORTE_ESS_OPAL_H

BEGIN_C_DECLS

ORTE_MODULE_DECLSPEC extern orte_ess_base_component_t mca_ess_orcm_component;

END_C_DECLS

#endif /* ORTE_ESS_OPAL_H */
