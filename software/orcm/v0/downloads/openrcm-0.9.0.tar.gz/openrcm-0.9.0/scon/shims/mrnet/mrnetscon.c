/*
 * Copyright (c) 2014      Intel, Inc. All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */

#include "orte_config.h"
#include "orte/constants.h"

#include "mrnetscon.h"

int mrnetscon_init(void)
{
    return ORTE_SUCCESS;
}

void mrnetscon_finalize(void)
{
    return;
}
