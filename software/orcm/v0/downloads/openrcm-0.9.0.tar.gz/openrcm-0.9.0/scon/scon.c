/*
 * Copyright (c) 2014      Intel, Inc. All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */

#include "orte_config.h"
#include "orte/constants.h"

#include "scon/scon.h"

int scon_init(void)
{
    return ORTE_SUCCESS;
}

void scon_finalize(void)
{
    return;
}
