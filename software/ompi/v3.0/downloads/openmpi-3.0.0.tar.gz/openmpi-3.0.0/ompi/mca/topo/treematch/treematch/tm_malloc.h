#include <stdlib.h>
void *my_malloc(size_t size, char *, int);
void *my_calloc(size_t count, size_t size, char *, int);
void my_free(void *ptr);
void my_mem_check(void);
